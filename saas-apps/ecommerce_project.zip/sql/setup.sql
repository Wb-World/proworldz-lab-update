-- Secure-Worldz-Official Vultrum SaaS Lab - Extended Database Schema
-- Version 2.0 (High-End Premium Training Environment)

CREATE DATABASE IF NOT EXISTS `saas_ecommerce_vulnerable`;
USE `saas_ecommerce_vulnerable`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `roles` VALUES (1, 'Admin');
INSERT INTO `roles` VALUES (2, 'Seller');
INSERT INTO `roles` VALUES (3, 'Customer');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL, -- VULNERABILITY: Stored as MD5 or Plaintext for training
  `role_id` int(11) DEFAULT 3,
  `profile_pic` varchar(255) DEFAULT 'default.png',
  `reset_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Password for all seed users is 'password123' hashed with MD5 (5f4dcc3b5aa765d61d8327deb882cf99)
INSERT INTO `users` VALUES (1, 'vultrum_admin', 'admin@vultrum.lab', '5f4dcc3b5aa765d61d8327deb882cf99', 1, 'admin.png', NULL, CURRENT_TIMESTAMP);
INSERT INTO `users` VALUES (2, 'premium_seller', 'seller@vultrum.lab', '5f4dcc3b5aa765d61d8327deb882cf99', 2, 'seller.png', NULL, CURRENT_TIMESTAMP);
INSERT INTO `users` VALUES (3, 'elite_customer', 'customer@vultrum.lab', '5f4dcc3b5aa765d61d8327deb882cf99', 3, 'customer.png', NULL, CURRENT_TIMESTAMP);

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` VALUES (1, 'Quantum Hardware', 'Next-generation tech artifacts and computing modules.');
INSERT INTO `categories` VALUES (2, 'Neural Wearables', 'Smart clothing and neural-link interfaces.');
INSERT INTO `categories` VALUES (3, 'Digital Assets', 'High-end software licenses and exclusive virtual items.');
INSERT INTO `categories` VALUES (4, 'Cyber Armor', 'Premium protective gear and hacking aesthetic apparel.');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seller_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text, -- VULNERABILITY: Stored as HTML, rendered with dangerouslySetInnerHTML (DOM XSS)
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`),
  FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Extended Seed Data with Images from Unsplash API (Source: unsplash.com)
INSERT INTO `products` VALUES (1, 2, 1, 'V-Nexus Core GPU', '<p>The ultimate <strong>Quantum Processing Unit</strong> for neural training. <i>Warning: Requires liquid nitrogen cooling.</i></p>', 1499.00, 5, 'https://images.unsplash.com/photo-1591405351990-4726e331f141?q=80&w=800', 1, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (2, 2, 2, 'Neural Link Visor', '<p>Augmented reality interface with direct neural stimulation. <strong>Experience the matrix.</strong></p>', 899.00, 12, 'https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?q=80&w=800', 1, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (3, 2, 4, 'Interceptor Stealth Hoodie', '<p>Fabricated with signal-blocking materials. <u>Invisible to thermal sensors.</u></p>', 120.00, 50, 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=800', 0, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (4, 2, 1, 'Quantum Encrypted SSD', '<p>Military-grade storage with self-destruct mechanism. <b>Your data belongs only to you.</b></p>', 450.00, 20, 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?q=80&w=800', 0, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (5, 2, 2, 'Cyber-Pulse Gloves', '<p>Haptic feedback gloves with integrated NFC hacking modules. <i>Limited edition.</i></p>', 299.00, 15, 'https://images.unsplash.com/photo-1626388497673-206a4b182dca?q=80&w=800', 1, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (6, 2, 4, 'Vultrum Modular Backpack', '<p>Anti-theft design with built-in solar panels and charging ports.</p>', 180.00, 30, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=800', 0, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (7, 2, 1, 'Hyper-Thread CPU', '<p>Unleash 256 cores of pure processing power. Best for data mining.</p>', 2100.00, 10, 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800', 0, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (8, 2, 3, 'Admin Override Keycard', '<p>Simulation-only access bypass. <i>For training purposes only.</i></p>', 50.00, 100, 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?q=80&w=800', 0, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (9, 2, 2, 'Echo-Sonic Earbuds', '<p>Bone conduction technology with environmental audio filtering.</p>', 250.00, 40, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800', 0, CURRENT_TIMESTAMP);
INSERT INTO `products` VALUES (10, 2, 4, 'Cyberpunk Trench Coat', '<p>Water-resistant, neon-integrated aesthetics. Stay stylish in the rain.</p>', 350.00, 20, 'https://images.unsplash.com/photo-1544022613-e87cb17a48eb?q=80&w=800', 1, CURRENT_TIMESTAMP);

-- ----------------------------
-- Table structure for product_variants
-- ----------------------------
DROP TABLE IF EXISTS `product_variants`;
CREATE TABLE `product_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL, -- e.g., 'Size', 'Color'
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `product_variants` VALUES (1, 3, 'Size', 'Small');
INSERT INTO `product_variants` VALUES (2, 3, 'Size', 'Medium');
INSERT INTO `product_variants` VALUES (3, 3, 'Size', 'Large');
INSERT INTO `product_variants` VALUES (4, 1, 'Memory', '16GB');
INSERT INTO `product_variants` VALUES (5, 1, 'Memory', '32GB');

-- ----------------------------
-- Table structure for product_reviews
-- ----------------------------
DROP TABLE IF EXISTS `product_reviews`;
CREATE TABLE `product_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT 5,
  `comment` text, -- VULNERABILITY: Stored XSS
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `product_reviews` VALUES (1, 1, 3, 5, 'Absolutely mind-blowing performance! <script>console.log("XSS Stored!")</script>', CURRENT_TIMESTAMP);
INSERT INTO `product_reviews` VALUES (2, 2, 3, 4, 'Beautiful design, but a bit heavy on the forehead.', CURRENT_TIMESTAMP);

-- ----------------------------
-- Table structure for addresses
-- ----------------------------
DROP TABLE IF EXISTS `addresses`;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address_line1` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zip_code` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `addresses` VALUES (1, 3, '123 Cyber St', 'Neo Tokyo', '10101');
INSERT INTO `addresses` VALUES (2, 1, '999 Admin Blvd', 'Silicon Valley', '94000');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL, -- VULNERABILITY: Trusted client-side total
  `status` varchar(50) DEFAULT 'Paid',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `orders` VALUES (1, 3, 1, 1499.00, 'Delivered', CURRENT_TIMESTAMP);

-- ----------------------------
-- Table structure for notifications
-- ----------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `notifications` VALUES (1, 3, 'Welcome!', 'Welcome to the Vultrum Collective.', 1, CURRENT_TIMESTAMP);
INSERT INTO `notifications` VALUES (2, 3, 'Order Shipped', 'Your order #1 has been dispatched.', 0, CURRENT_TIMESTAMP);

SET FOREIGN_KEY_CHECKS = 1;
