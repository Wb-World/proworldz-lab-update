VULTRUM SAAS ECOMMERCE LAB
PROJECT SETUP AND RUN INSTRUCTIONS

Follow these steps to initialize and run the Vultrum Premium Lab locally.

STEP 1 DATABASE INITIALIZATION
Open your MySQL terminal or phpMyAdmin.
Import the file located at sql/setup.sql.
This will create the database saas_ecommerce_vulnerable and all required tables.
If using a script:
On Linux run bash setup.sh
On Windows run powershell ./setup.ps1

STEP 2 CONFIGURE DATABASE
Open config/database.php.
Ensure the host user and password match your local MySQL configuration.
Default settings are host localhost user root and pass root.

STEP 3 RUN API BACKEND
The API serves as the headless logic for the application.
Open a terminal in the root directory.
Command php -S localhost 8080 -t .
Keep this terminal open while using the application.

STEP 4 RUN FRONTEND UI
The UI is built with Next js and React.
Open a new terminal and navigate to the frontend folder.
Command 1 cd frontend
Command 2 npm install
Command 3 npm run dev
The UI will be available at http://localhost 3000.

IMPORTANT USAGE NOTES
Application Entry Visit http://localhost 3000 to view the landing page.
Security Training This laboratory contains intentional security flaws for ethical hacking practice.
Exploit Documentation Refer to EXPLOIT_REPORT.pdf for professional walkthroughs and payloads.

SYSTEM REQUIREMENTS
Node js v18 or higher
PHP v8.0 or higher
MySQL v5.7 or higher

Project maintained by Secure Worldz Official.
Stay Legal. Stay Secure.
