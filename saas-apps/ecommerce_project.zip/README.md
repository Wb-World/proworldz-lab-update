# Vultrum v2 - Headless SaaS eCommerce Lab

## 🌐 Modern Architecture
Welcome to the second version of **Vultrum**. We have upgraded the stack to a modern, decoupled architecture:
- **Frontend**: Next.js 14, TailwindCSS, React (located in `/frontend`)
- **Backend (API)**: PHP 8.0+ (located in `/api`)
- **Database**: MySQL

⚠️ **STILL INTENTIONALLY VULNERABLE**: This transition to Next.js has introduced new modern attack vectors, such as DOM XSS, Client-side logic bypass, and Insecure API consumption.

---

## 🏗️ New Project Structure

```text
saas-ecommerce/
├── api/                  # Headless PHP API (SQLi, Command Injection, Mass Assignment)
│   ├── auth.php
│   ├── products.php
│   ├── cart.php
│   └── ...
├── frontend/             # Next.js Application
│   ├── src/app/          # Pages and Routing
│   ├── src/components/   # Reusable UI Components
│   └── ...
├── config/               # DB Connection
├── sql/                  # MySQL Schema
└── README.md
```

---

## 🔥 New & Maintained Vulnerabilities

### Modern Frontend (Next.js)
- **DOM XSS**: `frontend/src/app/products/[id]/page.tsx` uses `dangerouslySetInnerHTML` for product descriptions and reviews.
- **Client-Side Price Manipulation**: `frontend/src/app/cart/page.tsx` calculates the total price on the client and sends it to the API trustingly.
- **Sensitive Data in LocalStorage**: User sessions and tokens are stored in unencrypted `localStorage`, accessible via script.
- **Insecure API Exposure**: Frontend comments and JS bundles might reveal hidden administrative endpoints.

### Headless API (PHP)
- **SQL Injection**: Still present in all API parameters across `api/products.php`, `api/auth.php`, etc.
- **Command Injection**: `api/admin.php?action=stats&host={host}` executes shell commands.
- **Mass Assignment**: `api/auth.php?action=register` allows specifying `role_id` in the JSON payload.
- **Broken Access Control**: Most API endpoints do not verify the user's role or even if they are logged in.
- **Permissive CORS**: `Access-Control-Allow-Origin: *` in all API headers.

---

## ⚙️ Setup Instructions

### 1. Backend (PHP API)
- Ensure Apache/PHP is pointing to the root directory.
- Database imports from `sql/setup.sql` are mandatory.
- Update `config/database.php`.
- Run PHP server: `php -S localhost:8080 -t .`

### 2. Frontend (Next.js)
- Navigate to `/frontend`.
- Install dependencies: `npm install`.
- Run development server: `npm run dev`.
- Access UI at `http://localhost:3000`.

---

## 🎯 Exploit Challenges

1. **Modern SQLi**: Exploit the `products.php` API by passing a crafted UNION SELECT payload via the frontend search bar (or direct API call to `http://localhost:8080`).
2. **Defeat the Economy**: Add items to your cart, and use Browser DevTools to modify the `total` payload in the network request to `0.01` before it reaches the `api/cart.php`.
3. **RCE via API**: Use the Admin dashboard's diagnostic tool to execute `cat ../config/database.php` via command injection.
4. **Account Takeover**: Steal a `localStorage` token from another user via the DOM XSS in product reviews.

**Educational Purpose Only. Stay Legal.**
