<?php
// api/profile.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once '../config/database.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    http_response_code(400);
    echo json_encode(["error" => "ID required"]);
    exit;
}

/**
 * VULNERABILITY: IDOR
 * No check if the requester is the owner of the profile.
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT users.id, users.username, users.email, users.profile_pic, roles.name as role 
            FROM users JOIN roles ON users.role_id = roles.id WHERE users.id = $id";
    $result = mysqli_query($conn, $sql);
    echo json_encode(mysqli_fetch_assoc($result));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    /**
     * VULNERABILITY: Mass Assignment
     * VULNERABILITY: SQL Injection
     */
    $updates = [];
    foreach ($data as $key => $val) {
        $updates[] = "$key = '$val'";
    }
    
    $sql = "UPDATE users SET " . implode(", ", $updates) . " WHERE id = $id";
    
    if (mysqli_query($conn, $sql)) {
        echo json_encode(["status" => "success"]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
    }
}
