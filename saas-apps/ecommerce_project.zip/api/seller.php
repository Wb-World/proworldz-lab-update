<?php
// api/seller.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once '../config/database.php';

$action = $_GET['action'] ?? '';

if ($action == 'add_product') {
    /**
     * VULNERABILITY: Unrestricted File Upload
     * We'll simulate file upload via base64 or multipart if they use it.
     * For now, let's assume they send JSON with image_name.
     */
    $data = json_decode(file_get_contents('php://input'), true);
    
    $name = $data['name'];
    $price = $data['price'];
    $desc = $data['description'];
    $seller_id = $data['seller_id'];
    $image = $data['image_name'] ?? 'default.jpg';

    /**
     * VULNERABILITY: SQL Injection
     */
    $sql = "INSERT INTO products (seller_id, name, description, price, image) 
            VALUES ($seller_id, '$name', '$desc', $price, '$image')";
    
    if (mysqli_query($conn, $sql)) {
         echo json_encode(["status" => "success", "id" => mysqli_insert_id($conn)]);
    } else {
         echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
    }
}

if ($action == 'my_products') {
    $seller_id = $_GET['seller_id'];
    /**
     * VULNERABILITY: IDOR
     */
    $res = mysqli_query($conn, "SELECT * FROM products WHERE seller_id = $seller_id");
    echo json_encode(mysqli_fetch_all($res, MYSQLI_ASSOC));
}
