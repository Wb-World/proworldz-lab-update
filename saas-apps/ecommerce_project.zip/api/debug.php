<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

/**
 * VULTRUM DEBUG CONSOLE
 * 
 * HINT: This file reveals sensitive internal state and helpfully shows 
 * exactly how to exploit the neighboring endpoints.
 */

// EXPLOIT HELPERS
$hints = [
    "sql_injection" => "Try using ' OR 1=1-- on the login or search endpoints.",
    "command_injection" => "Admin panel diagnostics uses shell_exec directly. Use ; to chain commands.",
    "idor" => "Look at the user_id parameter in order history and notifications APIs.",
    "xss" => "Reviews are rendered directly. Use <script> tags for stored XSS.",
    "path_traversal" => "system.php reads directly from the file param. Try ../config/database.php"
];

echo json_encode([
    "status" => "debug_active",
    "version" => "2.1.0-VULNERABLE",
    "hints" => $hints,
    "system_info" => php_uname(),
    "php_version" => phpversion(),
    "database_state" => "VULNERABLE_CONNECTED"
]);
