<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

include '../config/database.php';

$action = $_GET['action'] ?? '';

if ($action === 'list') {
    $uid = $_GET['user_id'] ?? 0;
    /**
     * VULNERABILITY: IDOR
     * Anyone can see addresses of any user.
     */
    $sql = "SELECT * FROM addresses WHERE user_id = $uid";
    $result = $conn->query($sql);
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
}

else if ($action === 'detail') {
    $id = $_GET['id'] ?? 0;
    /**
     * VULNERABILITY: SQL Injection
     */
    $sql = "SELECT * FROM addresses WHERE id = $id";
    $result = $conn->query($sql);
    echo json_encode($result->fetch_assoc());
}
