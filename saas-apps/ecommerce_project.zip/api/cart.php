<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');

include '../config/database.php';

$action = $_GET['action'] ?? '';

if ($action === 'apply_coupon') {
    $code = $_GET['code'] ?? '';
    /**
     * VULNERABILITY: Business Logic Flaw - Unlimited Coupon Use
     * Rationale: No validation on usage count or user restrictions.
     */
    if ($code === 'FREE100') {
        echo json_encode(['status' => 'success', 'discount' => 100, 'message' => 'Full discount applied!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid code']);
    }
}
