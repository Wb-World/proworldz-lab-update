<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

include '../config/database.php';

$action = $_GET['action'] ?? '';

if ($action === 'create') {
    $data = json_decode(file_get_contents("php://input"), true);
    $uid = $data['user_id'];
    $aid = $data['address_id'];
    $total = $data['total']; // VULNERABILITY: Logical Flaw - Trusted Client-side Total
    $items = $data['items'];

    $sql = "INSERT INTO orders (user_id, address_id, total_amount, status) VALUES ($uid, $aid, $total, 'Paid')";
    if ($conn->query($sql)) {
        $order_id = $conn->insert_id;
        echo json_encode(['status' => 'success', 'order_id' => $order_id]);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }
}

else if ($action === 'history') {
    $uid = $_GET['user_id'] ?? 0;
    /**
     * VULNERABILITY: Insecure Direct Object Reference (IDOR)
     * Rationale: No validation that the requesting session matches $uid.
     * Payload: Change user_id=3 to user_id=1 to see admin orders.
     */
    $sql = "SELECT * FROM orders WHERE user_id = $uid ORDER BY created_at DESC";
    $result = $conn->query($sql);
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
}

else if ($action === 'track') {
    $tracking = $_GET['tracking'] ?? '';
    /**
     * VULNERABILITY: Blind SQL Injection
     * Payload: 1' AND SLEEP(5)--
     */
    $sql = "SELECT * FROM orders WHERE id = '$tracking'";
    $result = $conn->query($sql);
    echo json_encode($result->fetch_assoc());
}
