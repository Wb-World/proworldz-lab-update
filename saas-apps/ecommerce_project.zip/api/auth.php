<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

include '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);
$action = $_GET['action'] ?? '';

if ($action === 'login') {
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';

    /**
     * VULNERABILITY: SQL Injection
     */
    $sql = "SELECT * FROM users WHERE (username = '$email' OR email = '$email') AND password = '" . md5($password) . "'";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

    if ($user) {
        echo json_encode([
            'status' => 'success',
            'token' => base64_encode($user['email']), // VULNERABILITY: Weak Token
            'user' => $user
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
    }
} 

else if ($action === 'register') {
    $username = $data['username'] ?? '';
    $email = $data['email'] ?? '';
    $password = md5($data['password'] ?? ''); // VULNERABILITY: Weak Hash (MD5)
    
    /**
     * VULNERABILITY: Mass Assignment
     */
    $role_id = $data['role_id'] ?? 3;

    $sql = "INSERT INTO users (username, email, password, role_id) VALUES ('$username', '$email', '$password', $role_id)";
    if ($conn->query($sql)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }
}

else if ($action === 'forgot_password') {
    $email = $data['email'] ?? '';
    $token = md5($email);
    $conn->query("UPDATE users SET reset_token = '$token' WHERE email = '$email'");
    
    $user_res = $conn->query("SELECT id FROM users WHERE email = '$email'");
    $user = $user_res->fetch_assoc();
    if ($user) {
        $msg = "Your password reset token is: " . $token;
        $conn->query("INSERT INTO notifications (user_id, title, message) VALUES ({$user['id']}, 'Security Alert', '$msg')");
    }
    echo json_encode(['status' => 'success', 'message' => 'Reset token sent.']);
}
?>
