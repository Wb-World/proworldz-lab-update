<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

include '../config/database.php';

$action = $_GET['action'] ?? '';

if ($action === 'list') {
    $search = $_GET['search'] ?? '';
    $category_id = $_GET['category_id'] ?? '';
    $sort = $_GET['sort'] ?? 'p.id';
    $order = $_GET['order'] ?? 'DESC';

    /**
     * VULNERABILITY: SQL Injection
     * HINT for Researchers: This query is unparameterized. 
     * Try Payload: ' UNION SELECT 1,2,user(),4,5,6,7,8,9,10--
     */
    $sql = "SELECT p.*, c.name as category_name, u.username as seller_name 
            FROM products p 
            JOIN categories c ON p.category_id = c.id 
            JOIN users u ON p.seller_id = u.id 
            WHERE p.name LIKE '%$search%'";

    if ($category_id) $sql .= " AND p.category_id = $category_id";
    
    // VULNERABILITY: SQL Injection in ORDER BY
    $sql .= " ORDER BY $sort $order";

    $result = $conn->query($sql);
    
    if (!$result) {
        // VULNERABILITY: SQL Error Disclosure
        echo json_encode(['error' => $conn->error, 'sql' => $sql]);
        exit;
    }

    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
}

else if ($action === 'detail') {
    $id = $_GET['id'] ?? 0;
    
    // VULNERABILITY: SQL Injection
    $sql = "SELECT p.*, c.name as category_name, u.username as seller_name 
            FROM products p 
            JOIN categories c ON p.category_id = c.id 
            JOIN users u ON p.seller_id = u.id 
            WHERE p.id = $id";
            
    $product_res = $conn->query($sql);
    $product = $product_res->fetch_assoc();

    if ($product) {
        $v_sql = "SELECT * FROM product_variants WHERE product_id = $id";
        $product['variants'] = $conn->query($v_sql)->fetch_all(MYSQLI_ASSOC);

        $r_sql = "SELECT r.*, u.username FROM product_reviews r JOIN users u ON r.user_id = u.id WHERE r.product_id = $id";
        $product['reviews'] = $conn->query($r_sql)->fetch_all(MYSQLI_ASSOC);
    }

    echo json_encode($product);
}

else if ($action === 'add_review') {
    $data = json_decode(file_get_contents("php://input"), true);
    $pid = $data['product_id'];
    $uid = $data['user_id'];
    $rate = $data['rating'];
    $comment = $data['comment'];

    /**
     * VULNERABILITY: Stored XSS
     * Rationale: Storing raw HTML/Script from user in DB.
     * Payload: <script>alert('Stealing cookies: ' + document.cookie)</script>
     */
    $sql = "INSERT INTO product_reviews (product_id, user_id, rating, comment) VALUES ($pid, $uid, $rate, '$comment')";
    $conn->query($sql);
    
    echo json_encode(['status' => 'success']);
}
