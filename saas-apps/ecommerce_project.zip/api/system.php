<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

/**
 * VULNERABILITY: Information Disclosure
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$action = $_GET['action'] ?? '';

if ($action === 'read_log') {
    $file = $_GET['file'] ?? '';
    /**
     * VULNERABILITY: Arbitrary File Read / Path Traversal
     * Rationale: Directly reading file from user input without sanitization.
     * Payload: index.php?action=read_log&file=../../config/database.php
     */
    if ($file) {
        $content = file_get_contents($file);
        echo json_encode(['status' => 'success', 'content' => $content]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No file specified']);
    }
}

else if ($action === 'set_header') {
    $header_name = $_GET['name'] ?? '';
    $header_val = $_GET['value'] ?? '';
    /**
     * VULNERABILITY: CRLF Injection / Header Injection
     * Rationale: Setting custom headers from user input.
     * Payload: value=test%0D%0ASet-Cookie:malicious=true
     */
    header("$header_name: $header_val");
    echo json_encode(['status' => 'success', 'message' => "Header $header_name set"]);
}

else if ($action === 'env') {
    /**
     * VULNERABILITY: Sensitive Data Exposure
     * Rationale: Dumping full server environment.
     */
    echo json_encode($_SERVER);
}
