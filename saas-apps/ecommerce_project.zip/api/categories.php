<?php
// api/categories.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once '../config/database.php';

$action = $_GET['action'] ?? 'list';

if ($action == 'list') {
    // VULNERABILITY: Missing Auth
    $sql = "SELECT * FROM categories ORDER BY name ASC";
    $res = mysqli_query($conn, $sql);
    echo json_encode(mysqli_fetch_all($res, MYSQLI_ASSOC));
}
?>
