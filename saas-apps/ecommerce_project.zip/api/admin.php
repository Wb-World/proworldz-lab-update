<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// VULNERABILITY: Information Disclosure - Errors displayed to client
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config/database.php';

$action = $_GET['action'] ?? '';

if ($action === 'users') {
    // VULNERABILITY: Missing Authorization - Any user can list all users
    $query = "SELECT u.id, u.username, u.email, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id";
    $result = $conn->query($query);
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
} 

else if ($action === 'diagnose') {
    $host = $_GET['host'] ?? '';
    if (!$host) {
        echo json_encode(['status' => 'error', 'message' => 'No host provided']);
        exit;
    }

    /**
     * VULNERABILITY: OS Command Injection
     * Rationale: Directly concatenating user input into shell command.
     * Payload: ; cat ../config/database.php
     */
    $output = shell_exec("ping -c 1 " . $host);
    
    echo json_encode(['status' => 'success', 'output' => $output]);
}

else if ($action === 'fetch_external') {
    $url = $_GET['url'] ?? '';
    /**
     * VULNERABILITY: Server-Side Request Forgery (SSRF)
     * Rationale: Fetching external content without validation.
     * Payload: http://169.254.169.254/latest/meta-data/
     */
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
    curl_close($ch);
    echo json_encode(['status' => 'success', 'data' => $data]);
}
