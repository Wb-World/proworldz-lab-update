<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include '../config/database.php';

$user_id = $_GET['user_id'] ?? 0;

/**
 * VULNERABILITY: Insecure Direct Object Reference (IDOR)
 * Rationale: No session verification. Anyone can see anyone's notifications.
 * This is critical as it reveals password reset tokens in some cases.
 */
$sql = "SELECT * FROM notifications WHERE user_id = $user_id ORDER BY created_at DESC";
$result = $conn->query($sql);

if ($result) {
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
} else {
    echo json_encode([]);
}
