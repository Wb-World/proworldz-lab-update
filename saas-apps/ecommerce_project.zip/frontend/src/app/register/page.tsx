'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { User, Mail, Lock, Camera, ArrowRight, Zap } from 'lucide-react';

export default function RegisterPage() {
    const [form, setForm] = useState({ username: '', email: '', password: '', role_id: 3 }); // Customer by default
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);

    const handleRegister = async (e: any) => {
        e.preventDefault();
        setLoading(true);
        const res = await fetch(`http://localhost:8080/api/auth.php?action=register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(form)
        });
        const data = await res.json();
        if (data.status === 'success') setSuccess(true);
        setLoading(false);
    };

    return (
        <div className="min-h-[90vh] flex items-center justify-center p-6 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-indigo-900/10 via-transparent to-transparent">
            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="w-full max-w-2xl glass p-16 rounded-[4rem] relative"
            >
                <div className="absolute top-10 right-10 opacity-10">
                    <Zap className="w-40 h-40 text-indigo-500" />
                </div>

                <div className="mb-12">
                    <h1 className="text-5xl font-black mb-4 tracking-tighter italic">Join The <br /><span className="text-indigo-500">Collective.</span></h1>
                    <p className="text-slate-500 font-medium">Create your credentials to access the Vultrum ecosystem.</p>
                </div>

                {success ? (
                    <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="text-center py-10">
                        <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 text-white text-3xl">✓</div>
                        <h2 className="text-3xl font-bold mb-4">Registration Complete!</h2>
                        <p className="text-slate-500 mb-8">Your account has been successfully initialized in our system.</p>
                        <Link href="/login" className="premium-button inline-block px-12">Enter Dashboard</Link>
                    </motion.div>
                ) : (
                    <form onSubmit={handleRegister} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="relative">
                                <User className="absolute left-6 top-5 w-5 h-5 text-slate-500" />
                                <input
                                    type="text"
                                    placeholder="Username"
                                    className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl pl-16 pr-6 py-4 focus:outline-none focus:border-indigo-500 transition-all font-medium"
                                    onChange={e => setForm({ ...form, username: e.target.value })}
                                />
                            </div>
                            <div className="relative">
                                <Mail className="absolute left-6 top-5 w-5 h-5 text-slate-500" />
                                <input
                                    type="email"
                                    placeholder="Email Protocol"
                                    className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl pl-16 pr-6 py-4 focus:outline-none focus:border-indigo-500 transition-all font-medium"
                                    onChange={e => setForm({ ...form, email: e.target.value })}
                                />
                            </div>
                        </div>

                        <div className="relative">
                            <Lock className="absolute left-6 top-5 w-5 h-5 text-slate-500" />
                            <input
                                type="password"
                                placeholder="Security Cipher (Password)"
                                className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl pl-16 pr-6 py-4 focus:outline-none focus:border-indigo-500 transition-all font-medium"
                                onChange={e => setForm({ ...form, password: e.target.value })}
                            />
                        </div>

                        <div className="p-6 bg-indigo-600/5 rounded-[2rem] border border-indigo-500/10 flex items-center justify-between">
                            <div>
                                <h4 className="text-sm font-bold text-indigo-400 uppercase tracking-widest mb-1">Account Role</h4>
                                <p className="text-[10px] text-slate-500">Choose your level of participation.</p>
                            </div>
                            <select
                                className="bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm font-bold focus:outline-none"
                                onChange={e => setForm({ ...form, role_id: parseInt(e.target.value) })}
                            >
                                <option value="3">Customer Node</option>
                                <option value="2">Merchant Access</option>
                                <option value="1">Admin Override</option>
                            </select>
                        </div>

                        <button
                            disabled={loading}
                            className="w-full premium-button h-16 text-lg flex items-center justify-center gap-3 mt-10"
                        >
                            {loading ? 'Initializing...' : 'Synthesize My Account'}
                            <ArrowRight className="w-5 h-5" />
                        </button>
                    </form>
                )}

                <div className="mt-12 text-center">
                    <p className="text-slate-500 text-sm">
                        Already a member? <Link href="/login" className="text-indigo-400 font-bold hover:underline ml-1">Authenticate Here</Link>
                    </p>
                </div>
            </motion.div>
        </div>
    );
}
