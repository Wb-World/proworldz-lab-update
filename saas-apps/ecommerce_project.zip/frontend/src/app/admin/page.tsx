'use client';
import { useState, useEffect } from 'react';

export default function AdminPage() {
    const [host, setHost] = useState('');
    const [output, setOutput] = useState('');
    const [users, setUsers] = useState([]);
    const [orders, setOrders] = useState([]);
    const [activeTab, setActiveTab] = useState('users');

    useEffect(() => {
        fetch('http://localhost:8080/api/admin.php?action=users').then(res => res.json()).then(setUsers);
        fetch('http://localhost:8080/api/orders.php?action=history&user_id=1').then(res => res.json()).then(setOrders); // Mocking full history via ID 1 for demo logic
    }, []);

    const handlePing = async () => {
        /**
         * VULNERABILITY: Command Injection via API host parameter.
         */
        const res = await fetch(`http://localhost:8080/api/admin.php?action=stats&host=${host}`);
        const data = await res.json();
        setOutput(data.output);
    };

    return (
        <div className="container mx-auto px-4 pb-20">
            <div className="flex justify-between items-center mb-12">
                <h1 className="text-4xl font-bold text-red-500 tracking-tighter uppercase">Vultrum Control Center</h1>
                <div className="flex gap-4">
                    <button onClick={() => setActiveTab('users')} className={`px-6 py-2 rounded-xl font-bold ${activeTab === 'users' ? 'bg-red-600' : 'bg-slate-800'}`}>Users</button>
                    <button onClick={() => setActiveTab('orders')} className={`px-6 py-2 rounded-xl font-bold ${activeTab === 'orders' ? 'bg-red-600' : 'bg-slate-800'}`}>Orders</button>
                    <button onClick={() => setActiveTab('diag')} className={`px-6 py-2 rounded-xl font-bold ${activeTab === 'diag' ? 'bg-red-600' : 'bg-slate-800'}`}>Diagnostics</button>
                </div>
            </div>

            {activeTab === 'users' && (
                <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800">
                    <h2 className="text-2xl font-bold mb-6">User Database</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {users.map((u: any) => (
                            <div key={u.id} className="p-6 bg-slate-800/50 rounded-2xl border border-slate-800 group">
                                <div className="flex justify-between items-start mb-4">
                                    <p className="font-bold">{u.username}</p>
                                    <span className="text-[10px] bg-red-900/30 text-red-500 px-2 py-1 rounded">ID: {u.id}</span>
                                </div>
                                <p className="text-slate-500 text-sm mb-6">{u.email}</p>
                                <div className="flex justify-between items-center">
                                    <span className="text-blue-400 font-bold text-xs uppercase">{u.role_name}</span>
                                    <button className="text-xs text-slate-500 hover:text-red-500">Edit Permissions</button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'orders' && (
                <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800">
                    <h2 className="text-2xl font-bold mb-6">Global Order Stream</h2>
                    <div className="space-y-4">
                        {orders.map((o: any) => (
                            <div key={o.id} className="flex flex-col md:flex-row justify-between p-6 bg-slate-800/30 rounded-2xl border border-slate-800 gap-4">
                                <div>
                                    <p className="font-bold">Order #{o.id} - User ID: {o.user_id}</p>
                                    <p className="text-xs text-slate-500">{o.created_at}</p>
                                </div>
                                <div className="flex items-center gap-6">
                                    <div className="text-right">
                                        <p className="text-green-500 font-mono font-bold">$ {o.total_amount}</p>
                                        <p className="text-[10px] text-slate-400 uppercase tracking-widest">{o.status}</p>
                                    </div>
                                    <select className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1 text-xs">
                                        <option>Update Status</option>
                                        <option>Shipped</option>
                                        <option>Refunded</option>
                                        <option>Cancelled</option>
                                    </select>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'diag' && (
                <div className="max-w-2xl mx-auto bg-slate-900 p-8 rounded-3xl border border-slate-800">
                    <h2 className="text-2xl font-bold mb-6">Network Diagnostics</h2>
                    <div className="flex gap-2 mb-6">
                        <input
                            type="text"
                            placeholder="Domain or IP..."
                            value={host}
                            onChange={(e) => setHost(e.target.value)}
                            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 focus:outline-none focus:border-red-500 font-mono"
                        />
                        <button onClick={handlePing} className="bg-red-600 px-8 py-2 rounded-xl font-bold hover:bg-red-700 transition-colors">Trace</button>
                    </div>
                    {output && (
                        <div className="relative">
                            <div className="absolute top-3 right-4 text-[10px] text-slate-600 uppercase font-bold">Terminal Output</div>
                            <pre className="bg-black text-green-500 p-8 rounded-2xl font-mono text-xs overflow-x-auto border border-slate-800 shadow-inner">
                                {output}
                            </pre>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
