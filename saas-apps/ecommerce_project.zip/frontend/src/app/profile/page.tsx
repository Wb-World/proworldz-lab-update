'use client';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Package, Bell, Settings, ArrowRight, Shield, CreditCard, MapPin } from 'lucide-react';

export default function ProfileDashboard() {
    const [user, setUser] = useState<any>(null);
    const [orders, setOrders] = useState([]);
    const [notifs, setNotifs] = useState([]);
    const [activeTab, setActiveTab] = useState('profile');

    useEffect(() => {
        const userData = JSON.parse(localStorage.getItem('user') || '{}');
        if (!userData.id) {
            window.location.href = '/login';
            return;
        }
        setUser(userData);
        fetchOrders(userData.id);
        fetchNotifs(userData.id);
    }, []);

    const fetchOrders = async (uid: number) => {
        const res = await fetch(`http://localhost:8080/api/orders.php?action=history&user_id=${uid}`);
        setOrders(await res.json());
    };

    const fetchNotifs = async (uid: number) => {
        const res = await fetch(`http://localhost:8080/api/notify.php?user_id=${uid}`);
        setNotifs(await res.json());
    };

    if (!user) return <div className="p-40 text-center text-slate-500 animate-pulse font-black text-2xl uppercase tracking-[10px]">Synchronizing...</div>;

    const tabs = [
        { id: 'profile', name: 'Profile Stats', icon: User },
        { id: 'orders', name: 'Order History', icon: Package },
        { id: 'notifs', name: 'System Inbox', icon: Bell },
    ];

    return (
        <div className="container mx-auto px-6 pb-40">
            <div className="flex flex-col lg:flex-row gap-16">
                {/* Sidebar */}
                <div className="lg:w-80 shrink-0">
                    <div className="glass rounded-[3rem] p-8 space-y-2 sticky top-40">
                        <div className="px-4 mb-10">
                            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[4px] mb-2">Command Center</h3>
                            <div className="h-1 w-12 bg-indigo-600 rounded-full"></div>
                        </div>
                        {tabs.map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`w-full group flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'text-slate-400 hover:bg-slate-800'}`}
                            >
                                <tab.icon className={`w-5 h-5 transition-transform ${activeTab === tab.id ? 'scale-110' : 'group-hover:translate-x-1'}`} />
                                <span>{tab.name}</span>
                                {tab.id === 'notifs' && notifs.filter((n: any) => !n.is_read).length > 0 && (
                                    <span className="ml-auto w-2 h-2 bg-indigo-400 rounded-full animate-ping"></span>
                                )}
                            </button>
                        ))}
                        <div className="pt-10 px-4">
                            <button onClick={() => { localStorage.clear(); window.location.href = '/'; }} className="text-xs font-black text-red-500 uppercase tracking-widest hover:underline">
                                Terminate Session
                            </button>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-h-[600px]">
                    <AnimatePresence mode="wait">
                        {activeTab === 'profile' && (
                            <motion.div
                                key="profile"
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-12"
                            >
                                {/* Header Card */}
                                <div className="glass rounded-[4rem] p-12 flex flex-col md:flex-row items-center gap-12 relative overflow-hidden">
                                    <div className="absolute top-0 right-0 p-10 opacity-5">
                                        <Shield className="w-60 h-60 text-white" />
                                    </div>
                                    <div className="relative">
                                        <img src={`/assets/uploads/${user.profile_pic || 'default.png'}`} className="w-40 h-40 rounded-[3rem] border-4 border-slate-800 object-cover rotate-3" />
                                    </div>
                                    <div className="text-center md:text-left">
                                        <span className="bg-indigo-600/20 text-indigo-400 text-[10px] font-black uppercase tracking-[4px] px-4 py-1 rounded-full mb-4 inline-block">Verified Identity</span>
                                        <h2 className="text-6xl font-black tracking-tighter mb-2">{user.username}</h2>
                                        <p className="text-slate-500 font-medium">Core Member since {new Date().getFullYear()}</p>
                                    </div>
                                </div>

                                {/* Stats Grid */}
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                                    <div className="premium-card bg-slate-900/30">
                                        <CreditCard className="text-indigo-500 w-8 h-8 mb-6" />
                                        <h4 className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">Total Investments</h4>
                                        <p className="text-3xl font-black text-white">$ {orders.reduce((acc, oX: any) => acc + parseFloat(oX.total_amount), 0).toFixed(2)}</p>
                                    </div>
                                    <div className="premium-card bg-slate-900/30">
                                        <Package className="text-indigo-500 w-8 h-8 mb-6" />
                                        <h4 className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">Acquired Assets</h4>
                                        <p className="text-3xl font-black text-white">{orders.length} Units</p>
                                    </div>
                                    <div className="premium-card bg-slate-900/30">
                                        <Shield className="text-indigo-500 w-8 h-8 mb-6" />
                                        <h4 className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">Security Level</h4>
                                        <p className="text-3xl font-black text-white italic">{user.role_name || 'Standard'}</p>
                                    </div>
                                </div>

                                <div className="glass rounded-[3rem] p-10 flex justify-between items-center bg-indigo-600/5 border-indigo-500/10">
                                    <div className="flex items-center gap-6">
                                        <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white"><MapPin /></div>
                                        <div>
                                            <h4 className="font-bold text-white">Default Protocol Address</h4>
                                            <p className="text-sm text-slate-500">Not configured yet.</p>
                                        </div>
                                    </div>
                                    <button className="text-indigo-400 font-bold hover:underline">Update Protocol</button>
                                </div>
                            </motion.div>
                        )}

                        {activeTab === 'orders' && (
                            <motion.div
                                key="orders"
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-6"
                            >
                                <h2 className="text-3xl font-black italic mb-10">Purchase Stream</h2>
                                {orders.map((o: any) => (
                                    <div key={o.id} className="premium-card flex flex-col md:flex-row justify-between items-center gap-8 group bg-slate-900/40">
                                        <div className="flex items-center gap-8">
                                            <div className="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center font-black text-slate-500">
                                                #{o.id}
                                            </div>
                                            <div>
                                                <p className="font-bold text-lg mb-1">Quantum Transfer Complete</p>
                                                <span className="text-[10px] text-slate-500 font-black uppercase">{o.created_at}</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-12">
                                            <div className="text-right">
                                                <p className="text-2xl font-black text-indigo-400">$ {o.total_amount}</p>
                                                <span className={`text-[10px] font-black uppercase px-3 py-1 rounded-full ${o.status === 'Paid' ? 'bg-green-900/30 text-green-500' : 'bg-yellow-900/30 text-yellow-500'}`}>{o.status}</span>
                                            </div>
                                            <button className="w-12 h-12 glass rounded-full flex items-center justify-center group-hover:bg-indigo-600 transition-colors">
                                                <ArrowRight className="w-5 h-5" />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                                {orders.length === 0 && <p className="text-center py-20 text-slate-700 italic text-xl">No assets acquired yet.</p>}
                            </motion.div>
                        )}

                        {activeTab === 'notifs' && (
                            <motion.div
                                key="notifs"
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-6"
                            >
                                <h2 className="text-3xl font-black italic mb-10">System Inbox</h2>
                                {notifs.map((n: any) => (
                                    <div key={n.id} className="premium-card border-l-8 border-indigo-600 bg-slate-900/50">
                                        <div className="flex justify-between items-start mb-4">
                                            <h3 className="text-xl font-bold">{n.title}</h3>
                                            <span className="text-[10px] font-black text-slate-600 uppercase italic">{n.created_at}</span>
                                        </div>
                                        <p className="text-slate-400 leading-relaxed">{n.message}</p>
                                    </div>
                                ))}
                                {notifs.length === 0 && <p className="text-center py-20 text-slate-700 italic text-xl">Your inbox is clear.</p>}
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </div>
        </div>
    );
}
