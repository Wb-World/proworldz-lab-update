import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Vultrum - Vulnerable SaaS Lab",
  description: "Advanced cybersecurity training platform",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-slate-950 text-slate-100 min-h-screen`}>
        <Navbar />
        <main className="pt-24 min-h-[calc(100vh-200px)]">
          {children}
        </main>
        <footer className="mt-20 border-t border-slate-800 p-10 text-center text-slate-500">
          <p>&copy; 2026 Vultrum SaaS. Built with Next.js & PHP API.</p>
        </footer>
      </body>
    </html>
  );
}
