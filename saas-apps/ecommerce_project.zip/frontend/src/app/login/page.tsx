'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ShieldCheck, Mail, Lock, ArrowRight, Github } from 'lucide-react';

export default function LoginPage() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleLogin = async (e: any) => {
        e.preventDefault();
        setLoading(true);
        const res = await fetch(`http://localhost:8080/api/auth.php?action=login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();
        if (data.status === 'success') {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            window.location.href = '/';
        } else {
            setError(data.message);
            setLoading(false);
        }
    };

    return (
        <div className="min-h-[80vh] flex items-center justify-center p-6 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-900/20 via-transparent to-transparent">
            <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="w-full max-w-xl glass p-12 rounded-[3.5rem] relative overflow-hidden"
            >
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>

                <div className="text-center mb-12">
                    <div className="w-16 h-16 bg-indigo-600 rounded-[1.5rem] flex items-center justify-center mx-auto mb-6 rotate-6 shadow-2xl shadow-indigo-500/20">
                        <ShieldCheck className="text-white w-8 h-8" />
                    </div>
                    <h1 className="text-4xl font-black mb-3">Welcome Back</h1>
                    <p className="text-slate-500 font-medium">Continue your journey into the collective.</p>
                </div>

                {error && (
                    <motion.div initial={{ x: 20 }} animate={{ x: 0 }} className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl text-red-400 text-sm mb-8 text-center font-bold">
                        {error}
                    </motion.div>
                )}

                <form onSubmit={handleLogin} className="space-y-6">
                    <div className="relative">
                        <Mail className="absolute left-6 top-5 w-5 h-5 text-slate-500" />
                        <input
                            type="text"
                            placeholder="Email or Username"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl pl-16 pr-6 py-4 focus:outline-none focus:border-indigo-500 transition-all font-medium"
                        />
                    </div>
                    <div className="relative">
                        <Lock className="absolute left-6 top-5 w-5 h-5 text-slate-500" />
                        <input
                            type="password"
                            placeholder="Secret Cipher"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl pl-16 pr-6 py-4 focus:outline-none focus:border-indigo-500 transition-all font-medium"
                        />
                    </div>

                    <div className="text-right">
                        <Link href="/forgot-password" title="Wait, I forgot!" className="text-xs text-indigo-400 hover:text-white transition-colors font-bold uppercase tracking-widest">
                            Lost your cipher?
                        </Link>
                    </div>

                    <button
                        disabled={loading}
                        className="w-full premium-button h-16 text-lg flex items-center justify-center gap-3"
                    >
                        {loading ? 'Authenticating...' : 'Sign In to Vultrum'}
                        <ArrowRight className="w-5 h-5" />
                    </button>
                </form>

                <div className="mt-12 flex items-center gap-4 text-slate-700">
                    <div className="h-[1px] flex-1 bg-slate-800"></div>
                    <span className="text-[10px] uppercase font-black tracking-[4px]">Collective Entry</span>
                    <div className="h-[1px] flex-1 bg-slate-800"></div>
                </div>

                <div className="mt-10 grid grid-cols-2 gap-4">
                    <button className="glass p-4 rounded-2xl hover:bg-slate-800 transition-all flex items-center justify-center gap-3 text-sm font-bold">
                        <Github className="w-5 h-5" /> GitHub
                    </button>
                    <button className="glass p-4 rounded-2xl hover:bg-slate-800 transition-all flex items-center justify-center gap-3 text-sm font-bold italic">
                        <span className="text-indigo-400 font-black">G</span> Google
                    </button>
                </div>

                <p className="mt-12 text-center text-slate-500 text-sm">
                    New to the collective? <Link href="/register" className="text-indigo-400 font-bold hover:underline">Join Now</Link>
                </p>
            </motion.div>
        </div>
    );
}
