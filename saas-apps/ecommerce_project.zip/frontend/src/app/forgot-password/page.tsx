'use client';
import { useState } from 'react';

export default function ForgotPassword() {
    const [email, setEmail] = useState('');
    const [msg, setMsg] = useState('');

    const handleReset = async (e: any) => {
        e.preventDefault();
        /**
         * VULNERABILITY: SQL Injection via email
         */
        const res = await fetch(`http://localhost:8080/api/auth.php?action=forgot_password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        const data = await res.json();
        setMsg(data.message);
    };

    return (
        <div className="max-w-md mx-auto mt-20 p-10 bg-slate-900 rounded-3xl border border-slate-800">
            <h1 className="text-3xl font-bold mb-6 text-center text-blue-500">Reset Password</h1>
            <p className="text-slate-400 text-sm mb-8 text-center">Enter your email to receive a simulation reset token.</p>

            {msg && <div className="bg-blue-900/40 p-4 rounded-xl text-blue-300 mb-6 border border-blue-800 text-center">{msg}</div>}

            <form onSubmit={handleReset} className="space-y-6">
                <div>
                    <label className="block text-slate-500 mb-2">Email Address</label>
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 focus:outline-none"
                        required
                    />
                </div>
                <button className="w-full bg-blue-600 py-4 rounded-xl font-bold shadow-lg shadow-blue-500/10">
                    Send Reset Token
                </button>
            </form>

            <div className="mt-10 p-4 bg-yellow-900/20 border border-yellow-700/50 rounded-xl text-xs text-yellow-500">
                **LAB NOTE**: The email is simulated. Check your dashboard notifications after sending to find the token. Use SQLi for faster discovery!
            </div>
        </div>
    );
}
