'use client';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2, ShoppingBag, ArrowRight, Minus, Plus, CreditCard } from 'lucide-react';
import Link from 'next/link';

export default function CartPage() {
    const [cart, setCart] = useState<any[]>([]);

    useEffect(() => {
        const updateCart = () => {
            const data = JSON.parse(localStorage.getItem('cart') || '[]');
            setCart(data);
        };
        updateCart();
        window.addEventListener('storage', updateCart);
        return () => window.removeEventListener('storage', updateCart);
    }, []);

    const removeItem = (index: number) => {
        const newCart = [...cart];
        newCart.splice(index, 1);
        setCart(newCart);
        localStorage.setItem('cart', JSON.stringify(newCart));
        window.dispatchEvent(new Event('storage'));
    };

    const calculateTotal = () => {
        return cart.reduce((acc, item) => acc + (parseFloat(item.price) * (item.order_quantity || 1)), 0).toFixed(2);
    };

    return (
        <div className="container mx-auto px-6 py-20 min-h-screen">
            <h1 className="text-5xl font-black mb-16 italic flex items-center gap-6">
                Your Vault <span className="text-slate-700 text-2xl font-light">({cart.length} items)</span>
            </h1>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-16 items-start">
                {/* Left: Cart Items */}
                <div className="xl:col-span-2 space-y-8">
                    <AnimatePresence mode="popLayout">
                        {cart.map((item, i) => (
                            <motion.div
                                key={`${item.id}-${i}`}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                                layout
                                className="premium-card p-4 flex flex-col sm:flex-row items-center gap-10 bg-slate-900/30"
                            >
                                <div className="w-40 h-40 rounded-3xl overflow-hidden bg-slate-800 flex-shrink-0">
                                    <img src={item.image.startsWith('http') ? item.image : `/assets/products/${item.image}`} className="w-full h-full object-cover" />
                                </div>

                                <div className="flex-1 space-y-2 text-center sm:text-left">
                                    <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">{item.category_name}</p>
                                    <h3 className="text-2xl font-bold">{item.name}</h3>
                                    {item.selected_variant && (
                                        <div className="inline-block px-3 py-1 bg-slate-800 rounded-lg text-xs font-bold text-slate-400">
                                            Variant: {item.selected_variant.value}
                                        </div>
                                    )}
                                </div>

                                <div className="flex items-center gap-10">
                                    <div className="text-right">
                                        <p className="text-2xl font-black text-white">$ {item.price}</p>
                                        <p className="text-xs text-slate-500 font-bold">Qty: {item.order_quantity || 1}</p>
                                    </div>
                                    <button
                                        onClick={() => removeItem(i)}
                                        className="w-12 h-12 rounded-2xl bg-red-900/20 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all"
                                    >
                                        <Trash2 className="w-5 h-5" />
                                    </button>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>

                    {cart.length === 0 && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-center py-20 bg-slate-900/20 rounded-[3rem] border border-dashed border-slate-800"
                        >
                            <ShoppingBag className="w-20 h-20 text-slate-800 mx-auto mb-6" />
                            <h2 className="text-2xl font-bold text-slate-500 mb-6">Your vault is currently empty.</h2>
                            <Link href="/products" className="premium-button inline-block">Start Exploring</Link>
                        </motion.div>
                    )}
                </div>

                {/* Right: Summary */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-slate-900 p-10 rounded-[3rem] border border-slate-800 sticky top-40"
                >
                    <h2 className="text-2xl font-black mb-10 flex items-center gap-4">
                        <CreditCard className="text-indigo-500" />
                        Order Terminal
                    </h2>

                    <div className="space-y-6 mb-10">
                        <div className="flex justify-between text-slate-500 font-bold uppercase text-xs tracking-widest">
                            <span>Subtotal</span>
                            <span>$ {calculateTotal()}</span>
                        </div>
                        <div className="flex justify-between text-slate-500 font-bold uppercase text-xs tracking-widest">
                            <span>Shipping</span>
                            <span className="text-green-500 italic">FREE</span>
                        </div>
                        <div className="h-[1px] bg-slate-800"></div>
                        <div className="flex justify-between items-end">
                            <span className="text-xl font-bold text-slate-400">Total Price</span>
                            <span className="text-4xl font-black text-white">$ {calculateTotal()}</span>
                        </div>
                    </div>

                    <Link
                        href="/checkout"
                        className={`w-full premium-button flex items-center justify-center gap-3 text-lg h-16 ${cart.length === 0 ? 'pointer-events-none opacity-50' : ''}`}
                    >
                        Checkout Flow <ArrowRight className="w-5 h-5" />
                    </Link>

                    <div className="mt-8 p-4 bg-indigo-600/10 rounded-2xl border border-indigo-500/20 text-[10px] text-indigo-400 font-bold uppercase tracking-widest text-center">
                        Payment Encrypted via Vultrum Cipher
                    </div>
                </motion.div>
            </div>
        </div>
    );
}
