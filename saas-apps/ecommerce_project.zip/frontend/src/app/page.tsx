'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight, Zap, Shield, Sparkles, ShoppingBag, Globe, Cpu, Lock, Star, ChevronRight } from 'lucide-react';
import ProductCard from '@/components/ProductCard';

export default function HomePage() {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [email, setEmail] = useState('');

  useEffect(() => {
    fetch('http://localhost:8080/api/products.php?action=list&is_featured=1')
      .then(res => res.json())
      .then(data => setFeaturedProducts(data.slice(0, 4)));
  }, []);

  return (
    <div className="relative pt-20 overflow-hidden">
      {/* Dynamic Background */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[800px] bg-indigo-600/5 blur-[120px] rounded-full -z-10 animate-pulse"></div>

      {/* Hero Section */}
      <section className="container mx-auto px-6 pt-32 pb-40 text-center relative">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center gap-3 px-6 py-2 rounded-full glass border-indigo-500/20 text-indigo-400 text-xs font-black uppercase tracking-[0.3em] mb-12 shadow-2xl"
        >
          <Sparkles className="w-4 h-4 animate-spin-slow" />
          <span>Vultrum Quantum Labs Release v2.0</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-7xl md:text-9xl font-black mb-10 tracking-tighter leading-[0.9] text-white"
        >
          Forge Your <br />
          <span className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent italic mr-6">Digital</span>
          Destiny.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-xl text-slate-400 max-w-3xl mx-auto mb-16 leading-relaxed font-medium"
        >
          The premier ecosystem for high-end hardware, neural interfaces, and cyber-aesthetic apparel.
          Step into the collective and access exclusive quantum-grade technology.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="flex flex-wrap justify-center gap-8"
        >
          <Link href="/products" className="premium-button flex items-center gap-4 text-xl px-12 py-6 shadow-indigo-500/40">
            Explore Collection <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
          </Link>
          <Link href="/register" className="glass px-12 py-6 rounded-[2.5rem] font-bold hover:bg-slate-800 transition-all flex items-center gap-4 border border-white/5 text-lg">
            Join Collective <Zap className="w-6 h-6 text-indigo-500" />
          </Link>
        </motion.div>
      </section>

      {/* Brand Trust Signals */}
      <section className="border-y border-white/5 bg-white/2 py-20 px-6">
        <div className="container mx-auto flex flex-wrap justify-around items-center gap-10 opacity-30 grayscale hover:grayscale-0 transition-all duration-700">
          {['VULTRUM', 'NEXUS', 'QUANTUM', 'ETHER', 'SHIELD'].map(brand => (
            <span key={brand} className="text-3xl font-black tracking-widest text-white">{brand}</span>
          ))}
        </div>
      </section>

      {/* Featured Hardware Section */}
      <section className="container mx-auto px-6 py-40">
        <div className="flex justify-between items-end mb-20">
          <div>
            <h2 className="text-5xl font-black italic mb-4 tracking-tighter">Hardware <span className="text-indigo-500">Breakthroughs</span></h2>
            <p className="text-slate-500 font-medium">Limited availability quantum computing modules.</p>
          </div>
          <Link href="/products" className="text-indigo-400 font-bold flex items-center gap-2 hover:translate-x-2 transition-all">
            View All Artifacts <ChevronRight className="w-5 h-5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {featuredProducts.map((p: any) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Advanced Features Grid */}
      <section className="bg-indigo-600/5 py-40">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <motion.div className="premium-card p-12 bg-slate-900/40 border-indigo-500/10">
              <Cpu className="w-16 h-16 text-indigo-500 mb-8" />
              <h3 className="text-2xl font-black mb-4">Quantum Core</h3>
              <p className="text-slate-500 leading-relaxed font-medium">Proprietary V-Nexus processing units capable of 128-bit neural hashing in real-time.</p>
            </motion.div>
            <motion.div className="premium-card p-12 bg-slate-900/40 border-indigo-500/10">
              <Globe className="w-16 h-16 text-indigo-500 mb-8" />
              <h3 className="text-2xl font-black mb-4">Total Isolation</h3>
              <p className="text-slate-500 leading-relaxed font-medium">Global logistics network operating on encrypted protocols for discrete delivery.</p>
            </motion.div>
            <motion.div className="premium-card p-12 bg-slate-900/40 border-indigo-500/10">
              <Lock className="w-16 h-16 text-indigo-500 mb-8" />
              <h3 className="text-2xl font-black mb-4">Neural Shield</h3>
              <p className="text-slate-500 leading-relaxed font-medium">Advanced wearable tech integrated with biological signal encryption standards.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Collective Newsletter (VULNERABLE) */}
      <section className="container mx-auto px-6 py-40">
        <div className="glass rounded-[4rem] p-20 flex flex-col items-center text-center relative overflow-hidden bg-gradient-to-br from-indigo-900/20 to-purple-900/20 border-white/5">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 blur-[80px] rounded-full"></div>
          <h2 className="text-5xl font-black mb-6 italic tracking-tighter">Enter the <br />Vultrum Stream.</h2>
          <p className="text-slate-400 mb-12 max-w-xl font-medium">Receive secure updates on quantum releases and exclusive collective invitations.</p>

          <form className="w-full max-w-xl flex flex-col md:flex-row gap-4">
            {/* VULNERABILITY: Reflected XSS if email is echoed back in error/success */}
            <input
              type="email"
              placeholder="your@email.protocol"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 bg-slate-950/50 border border-slate-800 rounded-[2rem] px-8 py-5 focus:outline-none focus:border-indigo-500 transition-all font-bold"
            />
            <button className="premium-button px-10 py-5">Subscribe</button>
          </form>
        </div>
      </section>

      {/* Footer Decoration */}
      <div className="h-[400px] absolute bottom-0 left-0 w-full bg-gradient-to-t from-slate-950 to-transparent -z-10"></div>
    </div>
  );
}
