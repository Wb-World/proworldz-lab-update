'use client';
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Star, ShieldCheck, Truck, RefreshCw, ChevronLeft, Plus, Minus, Share2, Heart } from 'lucide-react';
import Link from 'next/link';

export default function ProductDetail() {
    const params = useParams();
    const id = params.id;
    const [product, setProduct] = useState<any>(null);
    const [selectedVariant, setSelectedVariant] = useState<any>(null);
    const [quantity, setQuantity] = useState(1);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch(`http://localhost:8080/api/products.php?action=detail&id=${id}`)
            .then(res => res.json())
            .then(data => {
                setProduct(data);
                if (data.variants && data.variants.length > 0) setSelectedVariant(data.variants[0]);
                setLoading(false);
            });
    }, [id]);

    const addToCart = () => {
        const cart = JSON.parse(localStorage.getItem('cart') || '[]');
        cart.push({
            ...product,
            selected_variant: selectedVariant,
            order_quantity: quantity,
            added_at: new Date().toISOString()
        });
        localStorage.setItem('cart', JSON.stringify(cart));
        window.dispatchEvent(new Event('storage'));
        alert('Added to your digital vault!');
    };

    if (loading) return (
        <div className="container mx-auto px-6 py-20 animate-pulse">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
                <div className="skeleton aspect-square rounded-[3rem]"></div>
                <div className="space-y-10">
                    <div className="skeleton h-10 w-3/4"></div>
                    <div className="skeleton h-40 w-full"></div>
                </div>
            </div>
        </div>
    );

    return (
        <div className="container mx-auto px-6 pt-10 pb-40">
            {/* Back Button */}
            <Link href="/products" className="inline-flex items-center gap-2 text-slate-500 hover:text-white transition-colors mb-12 group">
                <div className="w-10 h-10 glass rounded-xl flex items-center justify-center group-hover:bg-slate-800">
                    <ChevronLeft className="w-5 h-5" />
                </div>
                <span className="font-bold">Return to Market</span>
            </Link>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
                {/* Left: Image Gallery */}
                <motion.div
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="sticky top-40"
                >
                    <div className="premium-card p-0 overflow-hidden aspect-square">
                        <img
                            src={product.image.startsWith('http') ? product.image : `/assets/products/${product.image}`}
                            className="w-full h-full object-cover"
                        />
                        <div className="absolute top-6 right-6 flex flex-col gap-3">
                            <button className="glass w-12 h-12 rounded-2xl flex items-center justify-center text-slate-300 hover:text-red-500"><Heart className="w-5 h-5" /></button>
                            <button className="glass w-12 h-12 rounded-2xl flex items-center justify-center text-slate-300 hover:text-white"><Share2 className="w-5 h-5" /></button>
                        </div>
                    </div>
                </motion.div>

                {/* Right: Info */}
                <motion.div
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-10"
                >
                    <div className="space-y-4">
                        <div className="flex items-center gap-4">
                            <span className="bg-indigo-600/20 text-indigo-400 px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest">{product.category_name}</span>
                            <div className="flex items-center gap-1">
                                {[1, 2, 3, 4].map(s => <Star key={s} className="w-4 h-4 fill-yellow-500 text-yellow-500" />)}
                                <Star className="w-4 h-4 text-slate-700" />
                                <span className="ml-2 text-sm text-slate-500">(128 Reviews)</span>
                            </div>
                        </div>
                        <h1 className="text-5xl md:text-6xl font-black tracking-tighter">{product.name}</h1>
                        <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Authored by <span className="text-indigo-400">{product.seller_name}</span></p>
                    </div>

                    <div className="flex items-baseline gap-6">
                        <span className="text-6xl font-black text-white">$ {product.price}</span>
                        <span className="text-slate-600 line-through text-2xl font-bold">$ {(product.price * 1.5).toFixed(2)}</span>
                        <span className="bg-green-600/20 text-green-500 text-xs font-black px-3 py-1 rounded-lg">SAVE 33%</span>
                    </div>

                    <div
                        className="text-slate-400 leading-relaxed text-lg"
                        dangerouslySetInnerHTML={{ __html: product.description }}
                    />

                    {/* Variants */}
                    {product.variants && product.variants.length > 0 && (
                        <div>
                            <h3 className="text-sm font-black uppercase text-slate-600 tracking-widest mb-4">Select Configuration</h3>
                            <div className="flex flex-wrap gap-4">
                                {product.variants.map((v: any) => (
                                    <button
                                        key={v.id}
                                        onClick={() => setSelectedVariant(v)}
                                        className={`px-8 py-3 rounded-2xl font-bold transition-all border-2 ${selectedVariant?.id === v.id ? 'border-indigo-600 bg-indigo-600/10' : 'border-slate-800 hover:border-slate-700'}`}
                                    >
                                        {v.value}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Quantity & Cart */}
                    <div className="flex flex-wrap gap-6 items-center">
                        <div className="glass h-16 px-6 rounded-2xl flex items-center gap-8">
                            <button onClick={() => setQuantity(q => Math.max(1, q - 1))}><Minus className="w-5 h-5 text-slate-500" /></button>
                            <span className="text-xl font-bold font-mono w-4 text-center">{quantity}</span>
                            <button onClick={() => setQuantity(q => q + 1)}><Plus className="w-5 h-5 text-slate-500" /></button>
                        </div>
                        <button
                            onClick={addToCart}
                            className="premium-button flex-1 h-16 text-xl flex items-center justify-center gap-3"
                        >
                            Secure Item <ShoppingCart className="w-6 h-6" />
                        </button>
                    </div>

                    {/* Trust Badges */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t border-slate-800/50">
                        <div className="flex items-center gap-4 bg-slate-900/30 p-4 rounded-2xl">
                            <Truck className="w-6 h-6 text-indigo-500" />
                            <span className="text-xs font-bold text-slate-400">Quantum Delivery</span>
                        </div>
                        <div className="flex items-center gap-4 bg-slate-900/30 p-4 rounded-2xl">
                            <ShieldCheck className="w-6 h-6 text-indigo-500" />
                            <span className="text-xs font-bold text-slate-400">Buyer Protected</span>
                        </div>
                        <div className="flex items-center gap-4 bg-slate-900/30 p-4 rounded-2xl">
                            <RefreshCw className="w-6 h-6 text-indigo-500" />
                            <span className="text-xs font-bold text-slate-400">Instant Refund</span>
                        </div>
                    </div>
                </motion.div>
            </div>

            {/* Reviews Section Placeholder */}
            <section className="mt-40">
                <div className="flex justify-between items-end mb-16">
                    <h2 className="text-4xl font-black italic">Verified Feedback</h2>
                    <button className="text-indigo-400 font-bold hover:underline">Write a Review</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    {product.reviews && product.reviews.map((r: any) => (
                        <motion.div
                            key={r.id}
                            whileHover={{ scale: 1.02 }}
                            className="premium-card"
                        >
                            <div className="flex justify-between mb-4">
                                <span className="font-bold text-indigo-400">{r.username}</span>
                                <div className="flex gap-1 text-yellow-500">{Array(r.rating).fill(0).map((_, i) => <Star key={i} className="w-3 h-3 fill-current" />)}</div>
                            </div>
                            <p className="text-slate-400 leading-relaxed italic">"{r.comment}"</p>
                        </motion.div>
                    ))}
                </div>
            </section>
        </div>
    );
}
