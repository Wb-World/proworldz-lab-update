'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ProductCard from '@/components/ProductCard';
import { Search, SlidersHorizontal, ChevronDown, Rocket, Filter } from 'lucide-react';

export default function ProductsPage() {
    const [products, setProducts] = useState([]);
    const [categories, setCategories] = useState([]);
    const [search, setSearch] = useState('');
    const [selectedCat, setSelectedCat] = useState('');
    const [sort, setSort] = useState('p.id');
    const [order, setOrder] = useState('DESC');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchCategories();
        fetchProducts();
    }, []);

    const fetchCategories = async () => {
        const res = await fetch('http://localhost:8080/api/categories.php');
        if (res.ok) setCategories(await res.json());
    };

    const fetchProducts = async (q = search, cat = selectedCat, s = sort, o = order) => {
        setLoading(true);
        const url = `http://localhost:8080/api/products.php?action=list&search=${q}&category_id=${cat}&sort=${s}&order=${o}`;
        try {
            const response = await fetch(url);
            const data = await response.json();
            setProducts(data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container mx-auto px-6 pb-40 pt-10">
            {/* Page Header */}
            <header className="mb-20">
                <div className="flex flex-col md:flex-row justify-between items-end gap-10">
                    <div className="max-w-xl">
                        <motion.h1
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="text-5xl font-black mb-6 tracking-tighter"
                        >
                            The Quantum <br />
                            <span className="text-indigo-500 italic">Marketplace</span>
                        </motion.h1>
                        <p className="text-slate-500 leading-relaxed font-medium">
                            Discover the worlds most unique tech artifacts and premium gear.
                            Filtered for quality, designed for the future.
                        </p>
                    </div>

                    {/* Search & Stats */}
                    <div className="flex flex-col gap-4 text-right">
                        <span className="text-indigo-400 font-black text-sm uppercase tracking-widest">{products.length} Items Found</span>
                        <div className="flex gap-4">
                            <button className="glass p-4 rounded-2xl text-slate-400 hover:text-white transition-all"><Filter className="w-5 h-5" /></button>
                            <button className="glass p-4 rounded-2xl text-indigo-500 animate-pulse"><Rocket className="w-5 h-5" /></button>
                        </div>
                    </div>
                </div>
            </header>

            {/* Filter Bar */}
            <div className="sticky top-28 z-40 mb-16">
                <div className="glass shadow-2xl rounded-3xl p-4 flex flex-wrap gap-4 items-center justify-between">
                    <div className="flex flex-wrap gap-3">
                        <button
                            onClick={() => { setSelectedCat(''); fetchProducts(search, '', sort, order); }}
                            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${selectedCat === '' ? 'bg-indigo-600' : 'hover:bg-slate-800'}`}
                        >
                            All
                        </button>
                        {categories.map((c: any) => (
                            <button
                                key={c.id}
                                onClick={() => { setSelectedCat(c.id); fetchProducts(search, c.id, sort, order); }}
                                className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${selectedCat == c.id ? 'bg-indigo-600' : 'hover:bg-slate-800'}`}
                            >
                                {c.name}
                            </button>
                        ))}
                    </div>

                    <div className="flex gap-4 items-center flex-1 md:flex-none">
                        <div className="relative flex-1 md:w-80">
                            <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-500" />
                            <input
                                type="text"
                                placeholder="Search the future..."
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && fetchProducts()}
                                className="w-full bg-slate-800/50 border border-slate-700/50 rounded-2xl py-3 pl-12 pr-6 focus:outline-none focus:border-indigo-500 transition-all text-sm"
                            />
                        </div>
                        <select
                            onChange={(e) => {
                                const [s, o] = e.target.value.split('-');
                                setSort(s); setOrder(o); fetchProducts(search, selectedCat, s, o);
                            }}
                            className="bg-slate-800/50 border border-slate-700/50 p-3 rounded-2xl text-xs font-bold focus:outline-none focus:border-indigo-500"
                        >
                            <option value="p.id-DESC">New Arrivals</option>
                            <option value="p.price-ASC">Price: Low</option>
                            <option value="p.price-DESC">Price: High</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Product Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                <AnimatePresence>
                    {loading ? (
                        Array(8).fill(0).map((_, i) => (
                            <div key={i} className="premium-card h-[400px] flex flex-col gap-6">
                                <div className="skeleton h-2/3 rounded-3xl"></div>
                                <div className="space-y-3">
                                    <div className="skeleton h-6 w-3/4 rounded-full"></div>
                                    <div className="skeleton h-4 w-1/2 rounded-full"></div>
                                </div>
                            </div>
                        ))
                    ) : (
                        products.map((p: any) => (
                            <ProductCard key={p.id} product={p} />
                        ))
                    )}
                </AnimatePresence>
            </div>

            {!loading && products.length === 0 && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center py-40 text-center"
                >
                    <div className="w-20 h-20 bg-slate-900 rounded-[2.5rem] flex items-center justify-center mb-6 text-slate-600">
                        <Search className="w-10 h-10" />
                    </div>
                    <h2 className="text-3xl font-bold mb-2">No Artifacts Found</h2>
                    <p className="text-slate-500">Try adjusting your filters or search query.</p>
                </motion.div>
            )}
        </div>
    );
}
