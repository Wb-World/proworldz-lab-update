'use client';
import { useEffect, useState } from 'react';

export default function SellerDashboard() {
    const [products, setProducts] = useState([]);
    const [sales, setSales] = useState(0);
    const [user, setUser] = useState<any>(null);

    useEffect(() => {
        const userData = JSON.parse(localStorage.getItem('user') || '{}');
        if (userData.role_id !== 2 && userData.role_id !== 1) {
            window.location.href = '/';
            return;
        }
        setUser(userData);
        fetchSellerData(userData.id);
    }, []);

    const fetchSellerData = async (sid: number) => {
        // VULNERABILITY: Missing proper auth on API
        const res = await fetch(`http://localhost:8080/api/products.php?action=list&seller_id=${sid}`);
        const data = await res.json();
        setProducts(data);
        setSales(data.length * 150); // Simulated sales
    };

    return (
        <div className="container mx-auto px-4 pb-20">
            <div className="flex justify-between items-center mb-12">
                <h1 className="text-4xl font-black">Sales Command</h1>
                <button className="bg-blue-600 px-8 py-3 rounded-xl font-bold">+ New Product</button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800">
                    <p className="text-slate-500 uppercase text-xs font-black mb-2">Total Revenue</p>
                    <p className="text-4xl font-black text-green-500">$ {sales.toLocaleString()}</p>
                </div>
                <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800">
                    <p className="text-slate-500 uppercase text-xs font-black mb-2">Active Products</p>
                    <p className="text-4xl font-black text-blue-500">{products.length}</p>
                </div>
                <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800">
                    <p className="text-slate-500 uppercase text-xs font-black mb-2">Pending Orders</p>
                    <p className="text-4xl font-black text-yellow-500">3</p>
                </div>
            </div>

            <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-slate-800/50 text-slate-500 uppercase text-xs font-black">
                        <tr>
                            <th className="p-6">Product</th>
                            <th className="p-6">Price</th>
                            <th className="p-6">Stock</th>
                            <th className="p-6 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                        {products.map((p: any) => (
                            <tr key={p.id} className="hover:bg-slate-800/20 transition-colors">
                                <td className="p-6 flex items-center gap-4">
                                    <img src={`/assets/products/${p.image}`} className="w-12 h-12 rounded-lg object-cover" />
                                    <span className="font-bold">{p.name}</span>
                                </td>
                                <td className="p-6 font-mono text-blue-400">$ {p.price}</td>
                                <td className="p-6">
                                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${p.stock < 10 ? 'bg-red-900/30 text-red-500' : 'bg-green-900/30 text-green-500'}`}>
                                        {p.stock} units
                                    </span>
                                </td>
                                <td className="p-6 text-right">
                                    <button className="text-blue-500 mr-4 font-bold">Edit</button>
                                    {/**
                        * VULNERABILITY: IDOR in delete action
                        */}
                                    <button className="text-red-500 font-bold">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
