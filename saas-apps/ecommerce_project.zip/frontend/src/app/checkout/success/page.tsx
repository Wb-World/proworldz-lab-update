'use client';
import { useSearchParams } from 'next/navigation';
import { useEffect, useState, Suspense } from 'react';

function SuccessContent() {
    const searchParams = useSearchParams();
    const id = searchParams.get('id');
    const [order, setOrder] = useState<any>(null);

    useEffect(() => {
        if (id) {
            /**
             * VULNERABILITY: IDOR
             * Anyone can view details of any order simply by ID.
             */
            fetch(`http://localhost:8080/api/orders.php?action=track&tracking=${id}`) // Mocking tracking via ID for demo
                .then(res => res.json())
                .then(setOrder);
        }
    }, [id]);

    return (
        <div className="container mx-auto px-4 py-20 text-center">
            <div className="bg-slate-900 border border-slate-800 p-16 rounded-[3rem] max-w-2xl mx-auto">
                <div className="w-24 h-24 bg-green-900/30 text-green-500 rounded-full flex items-center justify-center text-5xl mx-auto mb-8 animate-bounce">
                    ✓
                </div>
                <h1 className="text-4xl font-black mb-4">Order Confirmed!</h1>
                <p className="text-slate-400 mb-10 text-lg">Thank you for your purchase. Your order <span className="text-blue-400">#{id}</span> is being processed.</p>

                {order && (
                    <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-800 text-left mb-10">
                        <div className="flex justify-between mb-2">
                            <span className="text-slate-500">Status</span>
                            <span className="font-bold text-yellow-500">{order.status}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-slate-500">Total Charged</span>
                            <span className="font-bold text-white">$ {order.total_amount}</span>
                        </div>
                    </div>
                )}

                <div className="flex gap-4 justify-center">
                    <a href="/" className="bg-slate-800 px-8 py-4 rounded-2xl font-bold">Home</a>
                    {/**
            * VULNERABILITY: Open Redirect via redirect_to param
            */}
                    <a
                        href={searchParams.get('redirect_to') || '/profile'}
                        className="bg-blue-600 px-8 py-4 rounded-2xl font-bold"
                    >
                        View My Orders
                    </a>
                </div>
            </div>
        </div>
    );
}

export default function CheckoutSuccess() {
    return (
        <Suspense fallback={<div>Loading Order...</div>}>
            <SuccessContent />
        </Suspense>
    );
}
