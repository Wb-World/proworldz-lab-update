'use client';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, CreditCard, ShieldCheck, ArrowRight, ChevronLeft, CheckCircle, Truck, Plus } from 'lucide-react';

export default function CheckoutPage() {
    const [step, setStep] = useState(1);
    const [cart, setCart] = useState<any[]>([]);
    const [user, setUser] = useState<any>(null);
    const [addresses, setAddresses] = useState([]);
    const [selectedAddr, setSelectedAddr] = useState<number | null>(null);

    useEffect(() => {
        const cartData = JSON.parse(localStorage.getItem('cart') || '[]');
        const userData = JSON.parse(localStorage.getItem('user') || '{}');
        if (!userData.id || cartData.length === 0) {
            window.location.href = '/';
            return;
        }
        setCart(cartData);
        setUser(userData);
        fetchAddresses(userData.id);
    }, []);

    const fetchAddresses = async (uid: number) => {
        const res = await fetch(`http://localhost:8080/api/address.php?action=list&user_id=${uid}`);
        const data = await res.json();
        setAddresses(data);
        if (data.length > 0) setSelectedAddr(data[0].id);
    };

    const handleCreateOrder = async () => {
        // VULNERABILITY HINT: The server trusts the 'total' sent from here!
        // Try changing 'total' to 0.01 in the DevTools console before clicking.
        const total = cart.reduce((acc, item: any) => acc + (parseFloat(item.price) * (item.order_quantity || 1)), 0).toFixed(2);

        const res = await fetch(`http://localhost:8080/api/orders.php?action=create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                user_id: user.id,
                total: total,
                address_id: selectedAddr,
                items: cart
            })
        });
        const data = await res.json();
        if (data.status === 'success') {
            localStorage.removeItem('cart');
            window.location.href = '/checkout/success?id=' + data.order_id;
        }
    };

    const calculateTotal = () => {
        return cart.reduce((acc, item) => acc + (parseFloat(item.price) * (item.order_quantity || 1)), 0).toFixed(2);
    };

    return (
        <div className="container mx-auto px-6 py-20 max-w-6xl">
            {/* Progress Tracker */}
            <div className="flex justify-center mb-20">
                <div className="flex items-center gap-4 glass px-8 py-4 rounded-[2rem]">
                    {[1, 2].map(s => (
                        <div key={s} className="flex items-center gap-4">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black transition-all ${step >= s ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-500'}`}>
                                {step > s ? <CheckCircle className="w-5 h-5" /> : s}
                            </div>
                            <span className={`text-sm font-bold uppercase tracking-widest ${step >= s ? 'text-white' : 'text-slate-600'}`}>
                                {s === 1 ? 'Logistics' : 'Payment'}
                            </span>
                            {s === 1 && <ArrowRight className="text-slate-800 w-4 h-4 mx-2" />}
                        </div>
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
                <div className="lg:col-span-3">
                    <AnimatePresence mode="wait">
                        {step === 1 && (
                            <motion.div
                                key="shipping"
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                className="space-y-10"
                            >
                                <h2 className="text-4xl font-black italic mb-10 flex items-center gap-4">
                                    <MapPin className="text-indigo-500" /> Logistics Node
                                </h2>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {addresses.map((a: any) => (
                                        <motion.div
                                            key={a.id}
                                            whileHover={{ scale: 1.02 }}
                                            onClick={() => setSelectedAddr(a.id)}
                                            className={`premium-card cursor-pointer border-2 transition-all p-8 ${selectedAddr === a.id ? 'border-indigo-600 bg-indigo-600/10' : 'border-slate-800'}`}
                                        >
                                            <div className="flex justify-between items-start mb-4">
                                                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Saved Point</span>
                                                {selectedAddr === a.id && <div className="w-4 h-4 bg-indigo-600 rounded-full"></div>}
                                            </div>
                                            <p className="text-xl font-bold mb-1">{a.address_line1}</p>
                                            <p className="text-slate-500 font-medium">{a.city}, {a.zip_code}</p>
                                        </motion.div>
                                    ))}

                                    <div className="premium-card border-2 border-dashed border-slate-800 flex flex-col items-center justify-center py-10 group cursor-pointer hover:border-indigo-500/50 transition-all">
                                        <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-slate-600 group-hover:text-indigo-500 mb-4">
                                            <Plus />
                                        </div>
                                        <span className="font-bold text-slate-500 uppercase tracking-widest text-xs">New Logistics Hub</span>
                                    </div>
                                </div>

                                <button
                                    onClick={() => setStep(2)}
                                    disabled={!selectedAddr}
                                    className="w-full premium-button h-20 text-xl flex items-center justify-center gap-4"
                                >
                                    Initialize Payment Protocol <ArrowRight />
                                </button>
                            </motion.div>
                        )}

                        {step === 2 && (
                            <motion.div
                                key="payment"
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-10"
                            >
                                <h2 className="text-4xl font-black italic mb-10 flex items-center gap-4">
                                    <CreditCard className="text-indigo-500" /> Payment Interface
                                </h2>

                                <div className="glass p-12 rounded-[3.5rem] bg-indigo-600/5 space-y-8">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-[3px] ml-1">Universal Card Number</label>
                                        <input type="text" placeholder="#### #### #### ####" className="input-field h-16 text-2xl font-mono tracking-widest" />
                                    </div>
                                    <div className="grid grid-cols-2 gap-8">
                                        <div className="space-y-2">
                                            <label className="text-[10px] font-black uppercase text-slate-500 tracking-[3px] ml-1">Expiry</label>
                                            <input type="text" placeholder="MM/YY" className="input-field h-16 text-xl font-mono" />
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-[10px] font-black uppercase text-slate-500 tracking-[3px] ml-1">CVV Security</label>
                                            <input type="password" placeholder="***" className="input-field h-16 text-xl font-mono" />
                                        </div>
                                    </div>
                                </div>

                                <div className="flex gap-6">
                                    <button onClick={() => setStep(1)} className="flex-1 glass h-20 rounded-[2rem] font-bold text-xl flex items-center justify-center gap-3">
                                        <ChevronLeft /> Back
                                    </button>
                                    <button
                                        onClick={handleCreateOrder}
                                        className="flex-[2] premium-button h-20 text-xl flex items-center justify-center gap-4"
                                    >
                                        Finalize $ {calculateTotal()} <ShieldCheck />
                                    </button>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                {/* Right: Summary */}
                <div className="lg:col-span-2">
                    <div className="glass p-10 rounded-[3rem] sticky top-40">
                        <h3 className="text-sm font-black uppercase text-slate-500 tracking-[4px] mb-8 pb-4 border-b border-slate-800">Order Artifacts</h3>
                        <div className="space-y-6 max-h-[400px] overflow-y-auto pr-2 mb-10 scrollbar-thin">
                            {cart.map((item, i) => (
                                <div key={i} className="flex gap-4 items-center">
                                    <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-800 flex-shrink-0">
                                        <img src={item.image.startsWith('http') ? item.image : `/assets/products/${item.image}`} className="w-full h-full object-cover" />
                                    </div>
                                    <div className="flex-1">
                                        <p className="font-bold text-sm line-clamp-1">{item.name}</p>
                                        <p className="text-xs text-slate-500 font-mono">Qty: {item.order_quantity || 1} × ${item.price}</p>
                                    </div>
                                    <span className="font-black text-sm">$ {(parseFloat(item.price) * (item.order_quantity || 1)).toFixed(2)}</span>
                                </div>
                            ))}
                        </div>

                        <div className="space-y-4 pt-6 border-t border-slate-800">
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-500 font-bold">Base Value</span>
                                <span className="font-black">$ {calculateTotal()}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-500 font-bold">Logistics</span>
                                <span className="text-green-500 font-black">COMPLIMENTARY</span>
                            </div>
                            <div className="flex justify-between items-end pt-4">
                                <span className="text-slate-400 font-black uppercase text-xs tracking-widest">Total Liability</span>
                                <span className="text-4xl font-black text-indigo-500">$ {calculateTotal()}</span>
                            </div>
                        </div>

                        <div className="mt-10 flex items-center gap-4 bg-indigo-600/10 p-4 rounded-2xl">
                            <Truck className="text-indigo-400 w-5 h-5 animate-bounce" />
                            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Next-Phase Quantum Shipping Enabled</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
