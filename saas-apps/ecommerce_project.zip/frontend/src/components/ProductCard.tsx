'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ShoppingCart, Star, Plus } from 'lucide-react';

export default function ProductCard({ product }: { product: any }) {
    return (
        <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="group relative"
        >
            <Link href={`/products/${product.id}`} className="block">
                <div className="premium-card h-full flex flex-col overflow-hidden p-0 bg-slate-900/50">
                    {/* Image Container */}
                    <div className="relative aspect-square overflow-hidden bg-slate-800">
                        <motion.img
                            whileHover={{ scale: 1.1 }}
                            transition={{ duration: 0.6, ease: [0.33, 1, 0.68, 1] }}
                            src={product.image.startsWith('http') ? product.image : `/assets/products/${product.image}`}
                            alt={product.name}
                            className="w-full h-full object-cover"
                        />
                        {product.is_featured && (
                            <div className="absolute top-4 left-4 bg-indigo-600 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full text-white shadow-lg">
                                Featured
                            </div>
                        )}
                        <div className="absolute bottom-4 right-4 flex gap-1">
                            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                            <Star className="w-3 h-3 text-slate-600" />
                        </div>

                        {/* Quick Actions Overlay */}
                        <div className="absolute inset-0 bg-indigo-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                            <span className="bg-white text-black px-6 py-2 rounded-full font-bold text-sm transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                View Details
                            </span>
                        </div>
                    </div>

                    {/* Info */}
                    <div className="p-6 flex-1 flex flex-col justify-between">
                        <div>
                            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">
                                {product.category_name || 'Tech'}
                            </p>
                            <h3 className="text-xl font-bold text-white group-hover:text-indigo-400 transition-colors line-clamp-1">
                                {product.name}
                            </h3>
                        </div>

                        <div className="mt-6 flex justify-between items-center">
                            <span className="text-2xl font-black text-white">$ {product.price}</span>
                            <button
                                onClick={(e) => {
                                    e.preventDefault();
                                    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
                                    cart.push(product);
                                    localStorage.setItem('cart', JSON.stringify(cart));
                                    window.dispatchEvent(new Event('storage'));
                                }}
                                className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white hover:scale-110 active:scale-95 transition-all shadow-lg shadow-indigo-500/20"
                            >
                                <Plus className="w-5 h-5" />
                            </button>
                        </div>
                    </div>
                </div>
            </Link>
        </motion.div>
    );
}
