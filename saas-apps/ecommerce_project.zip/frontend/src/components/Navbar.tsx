'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, User, Search, Menu, X, LogOut, LayoutDashboard, ShieldCheck } from 'lucide-react';

export default function Navbar() {
  const [user, setUser] = useState<any>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    const data = localStorage.getItem('user');
    if (data) setUser(JSON.parse(data));

    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);

    // Update cart count from localStorage
    const updateCart = () => {
      const cart = JSON.parse(localStorage.getItem('cart') || '[]');
      setCartCount(cart.length);
    };
    updateCart();
    window.addEventListener('storage', updateCart);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('storage', updateCart);
    };
  }, []);

  const logout = () => {
    localStorage.clear();
    window.location.href = '/';
  };

  return (
    <nav className={`fixed top-0 w-full z-[100] transition-all duration-500 ${isScrolled ? 'py-4' : 'py-8'}`}>
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className={`glass rounded-[2rem] px-8 py-3 flex justify-between items-center transition-all duration-500 ${isScrolled ? 'bg-slate-900/40' : 'bg-transparent border-transparent shadow-none'}`}
        >
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center rotate-6 group-hover:rotate-0 transition-all duration-500 shadow-lg shadow-indigo-500/20">
              <ShieldCheck className="text-white w-6 h-6" />
            </div>
            <span className="text-2xl font-black tracking-tighter bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
              VULTRUM
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-10">
            <Link href="/products" className="text-slate-400 hover:text-white transition-colors font-medium">Explore</Link>
            <div className="h-6 w-[1px] bg-slate-800"></div>

            <div className="flex items-center gap-6">
              {user ? (
                <>
                  <Link href="/profile" className="flex items-center gap-3 group">
                    <img src={`/assets/uploads/${user.profile_pic || 'default.png'}`} className="w-8 h-8 rounded-full border border-slate-700 group-hover:border-indigo-500 transition-colors" />
                    <span className="text-sm font-bold text-slate-300">{user.username}</span>
                  </Link>
                  {user.role_id === 1 && (
                    <Link href="/admin" className="text-red-400 hover:text-red-300">
                      <LayoutDashboard className="w-5 h-5" />
                    </Link>
                  )}
                  <Link href="/cart" className="relative group p-2 rounded-xl hover:bg-slate-800 transition-all">
                    <ShoppingCart className="w-6 h-6 text-slate-400 group-hover:text-white" />
                    {cartCount > 0 && (
                      <motion.span
                        initial={{ scale: 0 }} animate={{ scale: 1 }}
                        className="absolute -top-1 -right-1 bg-indigo-600 text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-bold"
                      >
                        {cartCount}
                      </motion.span>
                    )}
                  </Link>
                  <button onClick={logout} className="p-2 rounded-xl text-slate-500 hover:text-red-500 hover:bg-red-500/10 transition-all">
                    <LogOut className="w-5 h-5" />
                  </button>
                </>
              ) : (
                <>
                  <Link href="/login" className="text-slate-400 hover:text-white transition-colors">Sign In</Link>
                  <Link href="/register" className="premium-button text-sm">
                    Get Started
                  </Link>
                </>
              )}
            </div>
          </div>

          {/* Mobile Toggle */}
          <button className="lg:hidden text-white" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </motion.div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 top-[100px] z-[90] glass lg:hidden p-10 flex flex-col items-center gap-8 text-2xl h-fit rounded-b-[4rem]"
          >
            <Link href="/products" onClick={() => setIsMobileMenuOpen(false)}>Shop All</Link>
            <Link href="/cart" onClick={() => setIsMobileMenuOpen(false)}>Cart ({cartCount})</Link>
            {user ? (
              <>
                <Link href="/profile" onClick={() => setIsMobileMenuOpen(false)}>Dashboard</Link>
                <button onClick={logout} className="text-red-500">Logout</button>
              </>
            ) : (
              <Link href="/login" onClick={() => setIsMobileMenuOpen(false)}>Login</Link>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
