JTECH Employee Management System (EMS) v2.0-PRO

JTECH EMS is a modern ERP-lite solution designed to manage employees, tasks, and company operations efficiently. It helps organizations track performance, manage missions, and maintain strong security auditing.

--------------------------------------------------

KEY FEATURES

• Mission Intelligence Dashboard
  Real-time performance metrics, workload summaries, and progress charts.

• Advanced Task Kanban
  Track task progress (0–100%), set priorities, and manage file attachments.

• Security Audit Logs
  Secure and immutable history of all user actions (logins, updates, CRUD operations).

• Notification System
  Instant alerts for task assignments and updates.

• Employee Directory
  Manage employee lifecycle with advanced search and filtering.

• Modern UI
  Responsive design with dark mode and professional layout.

--------------------------------------------------

TECHNOLOGY STACK

Frontend        : Next.js 15, Tailwind CSS, Framer Motion
Data Visualization : Recharts
Backend         : Next.js API Routes (Serverless)
Database        : MySQL (Prisma ORM)
Authentication  : NextAuth.js (Role-Based Access Control)

--------------------------------------------------

REQUIREMENTS

• Node.js (v18 or higher)
• MySQL Server (v8 or higher)
• Git (optional)

--------------------------------------------------

INSTALLATION (LINUX / MAC)

1. Open terminal in the project folder
2. Run:
   chmod +x setup.sh
3. Then run:
   ./setup.sh
4. Enter your MySQL credentials when prompted

--------------------------------------------------

INSTALLATION (WINDOWS)

1. Open PowerShell as Administrator
2. Navigate to project folder
3. Run:
   .\setup.ps1
4. Enter your MySQL credentials when prompted

--------------------------------------------------

SETUP SCRIPT DOES

• Checks MySQL installation
• Creates database: jtech_ems
• Runs schema setup
• Installs dependencies
• Seeds sample data

--------------------------------------------------

START PROJECT

Run:
npm run dev

Open in browser:
http://localhost:3000

--------------------------------------------------

DEFAULT LOGIN

Admin
Email    : admin@jtech.com
Password : admin123

Employee
Email    : sarah@jtech.com
Password : user123

--------------------------------------------------

PROJECT STRUCTURE

/prisma        → Database schema and seed files
/src/app       → Main application routes
/src/components→ UI components
/src/lib       → Core utilities (Prisma, Auth)
/public        → Static assets

--------------------------------------------------

Build for Performance. Designed for JTECH.
© 2026 JTECH Corporate Systems Inc.