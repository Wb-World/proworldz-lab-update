# JTECH EMS Advanced Setup Script v2.0 for Windows

Clear-Host
Write-Host "----------------------------------------------------------------" -ForegroundColor Cyan
Write-Host "  🚀 JTECH Employee Management System - ADVANCED SETUP v2.0" -ForegroundColor Cyan
Write-Host "----------------------------------------------------------------" -ForegroundColor Cyan

# 1. Prerequisites Check
if (!(Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Node.js is missing. Please install Node.js v18+." -ForegroundColor Red
    return
}

# 2. Database Credentials
Write-Host ""
Write-Host "🔑 Database Configuration" -ForegroundColor Yellow
Write-Host "---------------------------" -ForegroundColor Yellow
$DB_HOST = Read-Host "Enter MySQL Host (default: localhost)"
if ([string]::IsNullOrWhiteSpace($DB_HOST)) { $DB_HOST = "localhost" }
$DB_USER = Read-Host "Enter MySQL Username (default: root)"
if ([string]::IsNullOrWhiteSpace($DB_USER)) { $DB_USER = "root" }
$DB_PASS = Read-Host -AsSecureString "Enter MySQL Password"
$DB_PASS_PLAIN = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($DB_PASS))
$DB_NAME = "jtech_enterprise"

# 3. MySQL Installation Check
if (!(Get-Command mysql -ErrorAction SilentlyContinue)) {
    Write-Host "⚠️ MySQL Client not found in PATH." -ForegroundColor Yellow
    Write-Host "Please ensure MySQL is installed and added to your System PATH." -ForegroundColor Yellow
    return
}

# 4. Database Setup
Write-Host "🔄 Creating database: $DB_NAME ..." -ForegroundColor Yellow
mysql -h "$DB_HOST" -u "$DB_USER" "-p$DB_PASS_PLAIN" -e "CREATE DATABASE IF NOT EXISTS $DB_NAME;" 2>$null

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Database connection failed. Check credentials." -ForegroundColor Red
    return
}

Write-Host "✅ Database ready." -ForegroundColor Green

# 5. Environment Configuration
Write-Host "🔄 Configuring .env file..." -ForegroundColor Yellow
$secret = [Convert]::ToBase64String((1..32 | ForEach-Object { [byte](Get-Random -Minimum 0 -Maximum 255) }))
$envContent = @"
DATABASE_URL="mysql://$DB_USER:$DB_PASS_PLAIN@$DB_HOST:3306/$DB_NAME"
NEXTAUTH_SECRET="$secret"
NEXTAUTH_URL="http://localhost:3000"
"@
$envContent | Out-File -FilePath .env -Encoding utf8

# 6. Dependency Installation
Write-Host "🔄 Installing Node.js dependencies..." -ForegroundColor Yellow
npm install --silent

# 7. Schema Execution
Write-Host "🔄 Running SQL Schema..." -ForegroundColor Yellow
mysql -h "$DB_HOST" -u "$DB_USER" "-p$DB_PASS_PLAIN" "$DB_NAME" < prisma/schema.sql

# 8. Prisma & Seeding
Write-Host "🔄 Syncing Prisma Client & Seeding Data..." -ForegroundColor Yellow
npx prisma generate
node prisma/seed.js

# 9. Final Instructions
Clear-Host
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  ✅ JTECH EMS SETUP COMPLETED SUCCESSFULLY!" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  🚀 TO START THE PROJECT:"
Write-Host "     1. Development Mode: npm run dev"
Write-Host "     2. Production Build: npm run build && npm start"
Write-Host ""
Write-Host "  💻 Access URL: http://localhost:3000"
Write-Host "  🔑 Default Admin: admin@jtech.com / admin123"
Write-Host ""
Write-Host "----------------------------------------------------------------"
Write-Host "  Application is ready for use." -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Green
