#!/bin/bash

# JTECH EMS Advanced Setup Script v2.0
# Optimized for Linux/macOS

clear
echo "----------------------------------------------------------------"
echo "  🚀 JTECH Employee Management System - ADVANCED SETUP v2.0"
echo "----------------------------------------------------------------"

# 1. OS Detection
OS="$(uname)"
case "$OS" in
    "Linux")
        DISTRO=$(cat /etc/os-release | grep ^ID= | cut -d'=' -f2)
        echo "✅ Detected OS: Linux ($DISTRO)"
        ;;
    "Darwin")
        echo "✅ Detected OS: macOS"
        ;;
    *)
        echo "⚠️ OS: $OS. Setup might require manual steps."
        ;;
esac

# 2. Prerequisites Check
check_cmd() {
    if ! command -v "$1" &> /dev/null; then
        return 1
    fi
    return 0
}

if ! check_cmd node; then
    echo "❌ Node.js is missing. Please install Node.js v18+."
    exit 1
fi

# 3. MySQL Installation/Check
install_mysql_linux() {
    echo "🔄 Attempting to install MySQL Server..."
    if [[ "$DISTRO" == "ubuntu" || "$DISTRO" == "debian" || "$DISTRO" == "kali" ]]; then
        sudo apt update && sudo apt install -y default-mysql-server
        sudo service mysql start
    elif [[ "$DISTRO" == "fedora" ]]; then
        sudo dnf install -y mysql-server
        sudo systemctl start mysqld
    else
        echo "⚠️ Could not auto-install MySQL for $DISTRO. Please install it manually."
    fi
}

if ! check_cmd mysql; then
    echo "⚠️ MySQL Client/Server not found."
    read -p "❓ Should I try to install it for you? (y/n): " confirm
    if [[ $confirm == "y" ]]; then
        if [[ "$OS" == "Linux" ]]; then
            install_mysql_linux
        elif [[ "$OS" == "Darwin" ]]; then
            brew install mysql
            brew services start mysql
        fi
    else
        echo "❌ Setup aborted. MySQL is required."
        exit 1
    fi
fi

# 4. Database Credentials
echo ""
echo "🔑 Database Configuration"
echo "---------------------------"
read -p "Enter MySQL Host (default: localhost): " DB_HOST
DB_HOST=${DB_HOST:-localhost}
read -p "Enter MySQL Username (default: root): " DB_USER
DB_USER=${DB_USER:-root}
read -p "Enter MySQL Password: " -s DB_PASS
echo ""
DB_NAME="jtech_enterprise"

# 5. Database Setup
echo "🔄 Creating database: $DB_NAME ..."
mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASS" -e "CREATE DATABASE IF NOT EXISTS $DB_NAME;" 2>/dev/null

if [ $? -ne 0 ]; then
    echo "❌ Database connection failed. Check credentials."
    exit 1
fi

echo "✅ Database ready."

# 6. Environment Configuration
echo "🔄 Configuring .env file..."
cat <<EOF > .env
DATABASE_URL="mysql://$DB_USER:$DB_PASS@$DB_HOST:3306/$DB_NAME"
NEXTAUTH_SECRET="$(openssl rand -base64 32)"
NEXTAUTH_URL="http://localhost:3000"
EOF

# 7. Dependency Installation
echo "🔄 Installing Node.js dependencies (this may take a few minutes)..."
npm install --silent

# 8. Schema Execution
echo "🔄 Running SQL Schema..."
mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" < prisma/schema.sql

# 9. Prisma & Seeding
echo "🔄 Syncing Prisma Client & Seeding Data..."
npx prisma generate
node prisma/seed.js

# 10. Final Instructions
clear
echo "================================================================"
echo "  ✅ JTECH EMS SETUP COMPLETED SUCCESSFULLY!"
echo "================================================================"
echo ""
echo "  🚀 TO START THE PROJECT:"
echo "     1. Development Mode: npm run dev"
echo "     2. Production Build: npm run build && npm start"
echo ""
echo "  💻 Access URL: http://localhost:3000"
echo "  🔑 Default Admin: admin@jtech.com / admin123"
echo ""
echo "----------------------------------------------------------------"
echo "  Application is ready for use."
echo "================================================================"
