"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
    LayoutDashboard,
    Users,
    CheckSquare,
    BarChart3,
    Settings,
    ShieldCheck,
    Bell,
    UserCircle,
    FileText,
    Activity
} from "lucide-react";
import { useSession } from "next-auth/react";

const navItems = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard, roles: ["ADMIN", "EMPLOYEE"] },
    { name: "Employees", href: "/employees", icon: Users, roles: ["ADMIN"] },
    { name: "Tasks", href: "/tasks", icon: CheckSquare, roles: ["ADMIN", "EMPLOYEE"] },
    { name: "Audit Logs", href: "/audit-logs", icon: Activity, roles: ["ADMIN"] },
    { name: "Reports", href: "/reports", icon: BarChart3, roles: ["ADMIN"] },
];

export function Sidebar() {
    const pathname = usePathname();
    const { data: session } = useSession();
    const userRole = (session?.user as any)?.role;

    const filteredItems = navItems.filter(item => item.roles.includes(userRole));

    return (
        <div className="w-64 min-h-screen bg-white border-r border-slate-200 flex flex-col p-6 fixed left-0 top-0 z-40 shadow-sm">
            <div className="flex items-center gap-3 mb-12 px-2">
                <div className="relative w-12 h-12">
                    <img
                        src="/logo.png"
                        alt="JTECH Logo"
                        className="w-full h-full object-contain rounded-xl shadow-xl shadow-indigo-100 ring-4 ring-indigo-50"
                    />
                </div>
                <div>
                    <h1 className="font-black text-slate-900 text-xl leading-none uppercase tracking-tighter">JTECH</h1>
                    <p className="text-indigo-600 text-[10px] font-bold uppercase tracking-[0.2em] mt-1 leading-none">Enterprise</p>
                </div>
            </div>

            <nav className="flex-1 flex flex-col gap-1.5">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-4 mb-2">Main Navigation</p>
                {filteredItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = pathname.startsWith(item.href);
                    return (
                        <Link
                            key={item.href}
                            href={item.href}
                            className={`sidebar-item group ${isActive ? "sidebar-item-active" : "sidebar-item-inactive"}`}
                        >
                            <Icon size={18} className={`${isActive ? "text-white" : "text-slate-400 group-hover:text-indigo-600"} transition-colors`} />
                            <span className="font-bold text-sm">{item.name}</span>
                        </Link>
                    );
                })}

                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-4 mt-8 mb-2">Personal</p>
                <Link
                    href="/profile"
                    className={`sidebar-item group ${pathname.startsWith("/profile") ? "sidebar-item-active" : "sidebar-item-inactive"}`}
                >
                    <UserCircle size={18} className={`${pathname.startsWith("/profile") ? "text-white" : "text-slate-400 group-hover:text-indigo-600"} transition-colors`} />
                    <span className="font-bold text-sm">My Profile</span>
                </Link>
                <Link
                    href="/notifications"
                    className={`sidebar-item group ${pathname.startsWith("/notifications") ? "sidebar-item-active" : "sidebar-item-inactive"}`}
                >
                    <Bell size={18} className={`${pathname.startsWith("/notifications") ? "text-white" : "text-slate-400 group-hover:text-indigo-600"} transition-colors`} />
                    <span className="font-bold text-sm">Notifications</span>
                </Link>
            </nav>

            <div className="mt-auto pt-8 border-t border-slate-100">
                <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100 mb-4">
                    <div className="flex items-center gap-2 text-indigo-700 mb-1.5">
                        <ShieldCheck size={16} />
                        <span className="text-[10px] font-black uppercase tracking-widest">{userRole} ACCESS</span>
                    </div>
                    <p className="text-slate-600 text-[11px] font-medium leading-relaxed">
                        {userRole === "ADMIN" ? "Operational control & system overrides enabled." : "Secure employee workspace activated."}
                    </p>
                </div>

                <p className="text-[9px] text-slate-400 font-bold text-center uppercase tracking-widest">
                    v2.0.4 Premium Core
                </p>
            </div>
        </div>
    );
}
