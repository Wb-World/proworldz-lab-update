"use client";

import { useSession, signOut } from "next-auth/react";
import { Search, Bell, LogOut, User as UserIcon, Calendar, Settings, Shield } from "lucide-react";
import { format } from "date-fns";
import { useState, useEffect } from "react";
import axios from "axios";
import Link from "next/link";

export function Topbar() {
    const { data: session } = useSession();
    const [unreadCount, setUnreadCount] = useState(0);
    const [showProfileMenu, setShowProfileMenu] = useState(false);

    useEffect(() => {
        const fetchNotifications = async () => {
            try {
                const res = await axios.get("/api/notifications");
                setUnreadCount(res.data.filter((n: any) => !n.isRead).length);
            } catch (err) {
                console.error("Failed to fetch notifications");
            }
        };
        if (session) fetchNotifications();
    }, [session]);

    return (
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 fixed top-0 right-0 left-64 z-30 px-8 flex items-center justify-between shadow-[0_1px_10px_rgba(0,0,0,0.02)]">
            <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-50 rounded-xl">
                    <Calendar size={18} className="text-indigo-600" />
                </div>
                <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">System Clock</p>
                    <p className="text-sm font-bold text-slate-800 mt-1">{format(new Date(), "MMMM do, yyyy")}</p>
                </div>
            </div>

            <div className="flex-1 max-w-xl mx-12">
                <div className="relative group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-all" size={18} />
                    <input
                        type="text"
                        placeholder="Universal search (Press '/' to focus)"
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-3 pl-12 pr-4 text-sm font-medium outline-none focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50/50 transition-all text-slate-700 placeholder:text-slate-400"
                    />
                </div>
            </div>

            <div className="flex items-center gap-5">
                <Link href="/notifications" className="relative p-2.5 text-slate-500 hover:bg-slate-50 hover:text-indigo-600 rounded-xl transition-all border border-transparent hover:border-slate-100">
                    <Bell size={22} />
                    {unreadCount > 0 && (
                        <span className="absolute top-2 right-2 w-4 h-4 bg-rose-500 border-2 border-white rounded-full flex items-center justify-center text-[8px] font-black text-white">
                            {unreadCount}
                        </span>
                    )}
                </Link>

                <div className="w-[1.5px] h-8 bg-slate-100 mx-1"></div>

                <div className="relative">
                    <button
                        onClick={() => setShowProfileMenu(!showProfileMenu)}
                        className="flex items-center gap-3 p-1.5 pl-3 hover:bg-slate-50 rounded-2xl transition-all border border-transparent hover:border-slate-100 group"
                    >
                        <div className="text-right hidden sm:block">
                            <p className="text-sm font-black text-slate-800 leading-none group-hover:text-indigo-600 transition-colors">{session?.user?.name}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5 flex items-center justify-end gap-1">
                                {(session?.user as any)?.role} <Shield size={10} className="text-indigo-400" />
                            </p>
                        </div>
                        <div className="w-10 h-10 bg-white border border-slate-200 rounded-xl flex items-center justify-center overflow-hidden shadow-lg shadow-shadow-indigo-50 group-hover:scale-105 transition-transform">
                            <img src="/logo.png" alt="User" className="w-8 h-8 object-contain" />
                        </div>
                    </button>

                    {showProfileMenu && (
                        <>
                            <div className="fixed inset-0 z-40" onClick={() => setShowProfileMenu(false)}></div>
                            <div className="absolute right-0 top-[120%] w-64 bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden z-50 p-2 animate-in fade-in slide-in-from-top-2 duration-200">
                                <div className="px-4 py-3 border-b border-slate-50 mb-1">
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Account</p>
                                    <p className="text-sm font-bold text-slate-800 truncate">{session?.user?.email}</p>
                                </div>

                                <Link href="/profile" className="flex items-center gap-3 px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 rounded-xl transition-all">
                                    <UserCircle size={18} />
                                    Account Settings
                                </Link>
                                <Link href="/help" className="flex items-center gap-3 px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 rounded-xl transition-all">
                                    <Settings size={18} />
                                    Help & Documentation
                                </Link>

                                <div className="h-[1px] bg-slate-50 my-1 mx-2"></div>

                                <button
                                    onClick={() => signOut({ callbackUrl: "/login" })}
                                    className="w-full flex items-center gap-3 px-4 py-3 text-sm font-black text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                                >
                                    <LogOut size={18} />
                                    Secure Sign Out
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </header>
    );
}

function UserCircle({ size }: { size: number }) {
    return <UserIcon size={size} />;
}
