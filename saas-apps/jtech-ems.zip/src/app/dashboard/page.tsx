"use client";

import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import {
    Users,
    CheckCircle2,
    Clock,
    TrendingUp,
    ArrowUpRight,
    Plus,
    Briefcase,
    Activity,
    ChevronRight,
    Monitor
} from "lucide-react";
import axios from "axios";
import { format } from "date-fns";
import Link from "next/link";
import toast from "react-hot-toast";
import { DashboardCharts } from "@/components/DashboardCharts";
import { TaskModal } from "@/components/TaskModal";

export default function DashboardPage() {
    const [data, setData] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const fetchData = async () => {
        try {
            const res = await axios.get("/api/stats");
            setData(res.data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    if (loading) return (
        <DashboardLayout>
            <div className="flex items-center justify-center min-h-[60vh]">
                <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
        </DashboardLayout>
    );

    const stats = [
        { label: "Active Force", value: data?.stats.employees, icon: Users, color: "from-blue-600 to-blue-700", trend: "+2.4%", desc: "vs last month" },
        { label: "Operational Tasks", value: data?.stats.tasks, icon: Briefcase, color: "from-indigo-600 to-indigo-700", trend: "+12%", desc: "efficiency up" },
        { label: "Success Rate", value: data?.stats.completed, icon: CheckCircle2, color: "from-emerald-500 to-emerald-600", trend: "+5.1%", desc: "goals reached" },
        { label: "Pending Review", value: data?.stats.pending, icon: Clock, color: "from-amber-500 to-amber-600", trend: "-2%", desc: "decreased latency" },
    ];

    return (
        <DashboardLayout>
            <TaskModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSuccess={fetchData}
            />
            <div className="flex items-center justify-between mb-10">
                <div>
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">Intelligence Dashboard</h2>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-2 flex items-center gap-2">
                        <Monitor size={12} className="text-indigo-600" />
                        Live Enterprise Monitoring System • Stable
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <button
                        onClick={() => toast.success("Running system-wide diagnostic telemetry...")}
                        className="bg-white text-slate-600 border border-slate-200 px-5 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm"
                    >
                        <Activity size={18} />
                        Diagnostic Report
                    </button>
                    <button
                        onClick={() => setIsModalOpen(true)}
                        className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-black flex items-center gap-2 hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all active:scale-95 group"
                    >
                        <Plus size={20} className="group-hover:rotate-90 transition-transform duration-300" />
                        New Operation
                    </button>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
                {stats.map((stat, i) => (
                    <div key={i} className="bg-white p-7 rounded-[2rem] border border-slate-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group overflow-hidden relative">
                        <div className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${stat.color} opacity-[0.03] -mr-8 -mt-8 rounded-full`}></div>
                        <div className="flex items-center justify-between mb-6">
                            <div className={`bg-gradient-to-br ${stat.color} w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-100`}>
                                <stat.icon size={26} />
                            </div>
                            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black ${stat.trend.startsWith("+") ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"}`}>
                                {stat.trend}
                            </div>
                        </div>
                        <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">{stat.label}</h3>
                        <p className="text-4xl font-black text-slate-900 mt-2 mb-1 tracking-tighter">{stat.value}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{stat.desc}</p>
                    </div>
                ))}
            </div>

            {/* Charts Section */}
            <div className="mb-10">
                <DashboardCharts />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                {/* Missions Feed */}
                <div className="lg:col-span-2 bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden shadow-sm">
                    <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                        <div>
                            <h3 className="font-black text-slate-900 leading-none">Critical Operations</h3>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-2">Active task tracking feed</p>
                        </div>
                        <Link href="/tasks" className="text-indigo-600 text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:gap-3 transition-all">
                            Full Archive <ChevronRight size={14} />
                        </Link>
                    </div>
                    <div className="divide-y divide-slate-50">
                        {data?.recentTasks.map((task: any) => (
                            <div key={task.id} className="p-8 hover:bg-slate-50/50 transition-all flex items-center justify-between group cursor-pointer">
                                <div className="flex items-center gap-6">
                                    <div className={`w-3 h-14 rounded-full ${task.priority === "HIGH" ? "bg-rose-500" :
                                        task.priority === "MEDIUM" ? "bg-amber-500" :
                                            "bg-blue-500"
                                        } shadow-md shadow-opacity-20`}></div>
                                    <div>
                                        {/* VULNERABILITY: STORED XSS */}
                                        <h4 className="font-black text-slate-900 text-lg group-hover:text-indigo-600 transition-colors leading-tight">{task.title}</h4>
                                        <div
                                            className="text-xs text-slate-500 mt-1"
                                            dangerouslySetInnerHTML={{ __html: task.description }}
                                        />
                                        <div className="flex items-center gap-4 mt-2">
                                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
                                                Agent: <span className="text-slate-800">{task.assignedTo?.name || "Unassigned"}</span>
                                            </p>
                                            <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
                                                {format(new Date(task.updatedAt), "HH:mm")} • Today
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex flex-col items-end gap-3">
                                    <div className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] shadow-sm ${task.status === "COMPLETED" ? "bg-emerald-500 text-white" :
                                        task.status === "PENDING" ? "bg-amber-500 text-white" :
                                            "bg-blue-600 text-white"
                                        }`}>
                                        {task.status.replace("_", " ")}
                                    </div>
                                    <div className="w-32 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                        <div className="h-full bg-indigo-500 rounded-full transition-all duration-1000" style={{ width: `${task.progress || 0}%` }}></div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Audit Log / Activity */}
                <div className="bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-2xl flex flex-col">
                    <div className="p-8 border-b border-white/5 bg-white/5">
                        <h3 className="font-black text-white leading-none">Security Audit Log</h3>
                        <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest mt-2">Immutable activity history</p>
                    </div>
                    <div className="p-8 flex-1 flex flex-col gap-8">
                        {data?.recentActivity?.length > 0 ? (
                            data.recentActivity.map((log: any) => (
                                <div key={log.id} className="flex gap-4 group">
                                    <div className="flex flex-col items-center gap-2">
                                        <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 ring-4 ring-indigo-500/20 group-hover:bg-indigo-400 transition-all"></div>
                                        <div className="w-0.5 flex-1 bg-white/10 group-last:bg-transparent"></div>
                                    </div>
                                    <div className="pb-2">
                                        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest leading-none mb-1.5">
                                            {log.action.replace("_", " ")}
                                        </p>
                                        <p className="text-sm font-bold text-slate-200 leading-snug group-hover:text-white transition-colors">
                                            {log.details || `Performed ${log.action} in ${log.module}`}
                                        </p>
                                        <div className="flex items-center gap-2 mt-2">
                                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{log.user?.name || "System"}</span>
                                            <span className="text-[10px] text-slate-700 font-black tracking-widest">•</span>
                                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{format(new Date(log.createdAt), "HH:mm")}</span>
                                        </div>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="flex flex-col items-center justify-center p-12 text-center opacity-30 h-full border-2 border-dashed border-white/10 rounded-3xl">
                                <Activity size={32} className="text-white mb-4" />
                                <p className="text-xs font-black text-white uppercase tracking-widest">Initializing Logs...</p>
                            </div>
                        )}

                        <button className="mt-auto w-full py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-white text-[10px] font-black uppercase tracking-[0.2em] transition-all border border-white/10">
                            Access Full Ops Log
                        </button>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}
