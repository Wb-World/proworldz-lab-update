"use client";

import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import {
    Bell,
    Trash2,
    CheckCircle,
    Clock,
    Info,
    AlertTriangle,
    XCircle,
    MoreVertical
} from "lucide-react";
import axios from "axios";
import { format } from "date-fns";
import toast from "react-hot-toast";

export default function NotificationsPage() {
    const [notifications, setNotifications] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchNotifications = async () => {
        try {
            const res = await axios.get("/api/notifications");
            setNotifications(res.data);
        } catch (err) {
            toast.error("Failed to load alerts");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchNotifications();
    }, []);

    const markAsRead = async (id: string) => {
        try {
            await axios.patch("/api/notifications", { id, isRead: true });
            setNotifications(notifications.map(n => n.id === id ? { ...n, isRead: true } : n));
        } catch (err) {
            toast.error("Update failed");
        }
    };

    const clearAll = async () => {
        try {
            await axios.delete("/api/notifications");
            setNotifications(notifications.filter(n => !n.isRead));
            toast.success("Read notifications cleared");
        } catch (err) {
            toast.error("Clear failed");
        }
    };

    const getIcon = (type: string) => {
        switch (type) {
            case "SUCCESS": return <CheckCircle className="text-emerald-500" size={20} />;
            case "WARNING": return <AlertTriangle className="text-amber-500" size={20} />;
            case "ERROR": return <XCircle className="text-rose-500" size={20} />;
            default: return <Info className="text-blue-500" size={20} />;
        }
    };

    return (
        <DashboardLayout>
            <div className="flex items-center justify-between mb-10">
                <div>
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">Signal Inbox</h2>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-2">Real-time system telemetry and personal alerts</p>
                </div>
                <button
                    onClick={clearAll}
                    className="bg-white text-slate-600 border border-slate-200 px-5 py-3 rounded-2xl font-bold flex items-center gap-3 hover:bg-slate-50 transition-all shadow-sm"
                >
                    <Trash2 size={18} />
                    Clear Log Archive
                </button>
            </div>

            <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden min-h-[60vh]">
                <div className="p-8 border-b border-slate-50 bg-slate-50/30 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
                            <Bell size={20} />
                        </div>
                        <p className="text-xs font-black text-slate-800 uppercase tracking-widest">Global Signals Feed</p>
                    </div>
                    <span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        {notifications.filter(n => !n.isRead).length} New Alerts
                    </span>
                </div>

                <div className="divide-y divide-slate-50">
                    {loading ? (
                        [...Array(4)].map((_, i) => (
                            <div key={i} className="p-8 animate-pulse">
                                <div className="h-4 bg-slate-100 rounded w-1/3 mb-4"></div>
                                <div className="h-4 bg-slate-50 rounded w-full"></div>
                            </div>
                        ))
                    ) : notifications.length > 0 ? (
                        notifications.map((n) => (
                            <div
                                key={n.id}
                                className={`p-8 hover:bg-slate-50/50 transition-all flex items-start gap-6 cursor-pointer relative group ${!n.isRead ? "border-l-4 border-indigo-600" : "border-l-4 border-transparent opacity-60"}`}
                                onClick={() => !n.isRead && markAsRead(n.id)}
                            >
                                <div className={`mt-1 p-3 rounded-2xl ${n.isRead ? "bg-slate-100" : "bg-white shadow-md border border-slate-100"}`}>
                                    {getIcon(n.type)}
                                </div>
                                <div className="flex-1">
                                    <div className="flex items-center gap-3 mb-1">
                                        <h4 className={`font-black text-lg ${!n.isRead ? "text-slate-900" : "text-slate-500"}`}>{n.title}</h4>
                                        {!n.isRead && <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>}
                                    </div>
                                    <p className="text-slate-600 font-medium leading-relaxed max-w-3xl">{n.message}</p>
                                    <div className="flex items-center gap-4 mt-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                        <span className="flex items-center gap-1.5"><Clock size={12} /> {format(new Date(n.createdAt), "MMMM do, HH:mm")}</span>
                                        <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                                        <span>Origin: JTECH Core v2</span>
                                    </div>
                                </div>
                                <button className="p-2 text-slate-300 hover:text-slate-600 hover:bg-white rounded-lg transition-all self-center">
                                    <MoreVertical size={18} />
                                </button>
                            </div>
                        ))
                    ) : (
                        <div className="flex flex-col items-center justify-center p-32 text-center">
                            <div className="w-20 h-20 bg-slate-50 rounded-[2rem] flex items-center justify-center text-slate-200 mb-6">
                                <Bell size={40} />
                            </div>
                            <h3 className="font-black text-slate-900 text-xl">All Channels Quiet</h3>
                            <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px] mt-2">No system alerts detected at this time</p>
                        </div>
                    )}
                </div>
            </div>
        </DashboardLayout>
    );
}
