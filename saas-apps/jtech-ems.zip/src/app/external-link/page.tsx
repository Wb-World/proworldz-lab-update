import { redirect } from 'next/navigation';

export default function RedirectPage({
    searchParams,
}: {
    searchParams: { url?: string };
}) {
    const url = searchParams.url || '/dashboard';

    // VULNERABILITY: OPEN REDIRECT
    // No validation on the redirect target.
    redirect(url);
}
