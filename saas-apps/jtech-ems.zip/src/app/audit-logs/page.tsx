"use client";

import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import {
    Activity,
    Search,
    Filter,
    Download,
    ShieldCheck,
    User,
    Monitor,
    Terminal
} from "lucide-react";
import axios from "axios";
import { format } from "date-fns";
import toast from "react-hot-toast";

export default function AuditLogsPage() {
    const [logs, setLogs] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState("");

    const fetchLogs = async () => {
        try {
            const res = await axios.get("/api/stats"); // Stats already returns recentActivity
            setLogs(res.data.recentActivity);
        } catch (err) {
            toast.error("Failed to load audit telemetry");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchLogs();
    }, []);

    return (
        <DashboardLayout>
            <div className="flex items-center justify-between mb-10">
                <div>
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">Compliance Telemetry</h2>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-2 flex items-center gap-2">
                        <ShieldCheck size={12} className="text-indigo-600" />
                        Security Audit Trail • Real-time Monitoring
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <button
                        onClick={() => toast.success("Generating tamper-proof audit export...")}
                        className="bg-white text-slate-600 border border-slate-200 px-5 py-3 rounded-2xl font-bold flex items-center gap-3 hover:bg-slate-50 transition-all shadow-sm"
                    >
                        <Download size={18} />
                        Export Archive
                    </button>
                </div>
            </div>

            <div className="bg-slate-950 rounded-[2.5rem] border border-slate-800 shadow-2xl overflow-hidden min-h-[60vh] flex flex-col font-mono">
                <div className="p-8 border-b border-slate-900 bg-slate-900/50 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-indigo-600/20 rounded-xl flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                            <Terminal size={20} />
                        </div>
                        <div>
                            <p className="text-xs font-black text-indigo-400 uppercase tracking-widest">Syslog Stream</p>
                            <p className="text-[10px] text-slate-500 font-bold mt-1 uppercase tracking-tighter">Event ID Correlation Active</p>
                        </div>
                    </div>
                    <div className="relative w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-700" size={14} />
                        <input
                            type="text"
                            placeholder="Filter entries..."
                            className="w-full bg-slate-900 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-xs font-bold text-slate-300 outline-none focus:border-indigo-500/50 transition-all"
                        />
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="border-b border-slate-900 text-slate-500">
                                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest">Timestamp</th>
                                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest">Operator</th>
                                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest">Vector</th>
                                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest">Action Payload</th>
                                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-right">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/[0.02]">
                            {loading ? (
                                [...Array(6)].map((_, i) => (
                                    <tr key={i} className="animate-pulse opacity-20">
                                        <td colSpan={5} className="px-8 py-6 h-4 bg-slate-900 mx-8 my-2 rounded-full"></td>
                                    </tr>
                                ))
                            ) : logs.length > 0 ? (
                                logs.map((log) => (
                                    <tr key={log.id} className="hover:bg-white/[0.01] group transition-colors">
                                        <td className="px-8 py-6">
                                            <span className="text-indigo-500 font-bold text-xs">{format(new Date(log.createdAt), "yyyy-MM-dd")}</span>
                                            <span className="text-slate-600 block text-[10px] mt-1">{format(new Date(log.createdAt), "HH:mm:ss.SSS")}</span>
                                        </td>
                                        <td className="px-8 py-6">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center text-slate-500 border border-slate-800">
                                                    <User size={14} />
                                                </div>
                                                <p className="text-xs font-bold text-slate-300">{log.user?.name || "System"}</p>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6">
                                            <span className="px-3 py-1 bg-slate-900 text-slate-500 rounded text-[10px] font-black uppercase tracking-widest border border-slate-800">
                                                {log.module}
                                            </span>
                                        </td>
                                        <td className="px-8 py-6">
                                            <p className="text-xs text-slate-400 group-hover:text-indigo-400 transition-colors">{log.details}</p>
                                        </td>
                                        <td className="px-8 py-6 text-right">
                                            <span className="inline-flex items-center gap-1.5 text-[9px] font-black text-emerald-500 uppercase tracking-widest px-2 py-0.5 rounded bg-emerald-500/5 border border-emerald-500/20">
                                                Success
                                            </span>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={5} className="px-8 py-20 text-center text-slate-700 text-xs font-bold uppercase tracking-widest">
                                        No activity records found in the current buffer.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="mt-auto p-8 border-t border-slate-900 bg-black/20 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Oracle Node Active</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Secure Handshake Established</span>
                        </div>
                    </div>
                    <p className="text-[10px] text-slate-700 font-bold uppercase tracking-widest">E2E Encryption Certified • RFC-5424 Compliant</p>
                </div>
            </div>
        </DashboardLayout>
    );
}
