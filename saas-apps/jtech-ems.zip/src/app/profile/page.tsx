"use client";

import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import {
    User,
    Mail,
    Shield,
    Lock,
    Save,
    Camera,
    CheckCircle2,
    AlertCircle
} from "lucide-react";
import axios from "axios";
import { useSession } from "next-auth/react";
import toast from "react-hot-toast";

export default function ProfilePage() {
    const { data: session, update } = useSession();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [profile, setProfile] = useState<any>({
        name: "",
        email: "",
        currentPassword: "",
        newPassword: "",
    });

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const res = await axios.get("/api/profile");
                setProfile({
                    ...profile,
                    name: res.data.name,
                    email: res.data.email,
                });
            } catch (err) {
                toast.error("Failed to load profile");
            } finally {
                setLoading(false);
            }
        };
        fetchProfile();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSaving(true);
        try {
            await axios.patch("/api/profile", profile);
            toast.success("Profile updated successfully");
            await update(); // Update session
        } catch (err: any) {
            toast.error(err.response?.data?.error || "Failed to update profile");
        } finally {
            setSaving(false);
        }
    };

    if (loading) return (
        <DashboardLayout>
            <div className="flex items-center justify-center min-h-[60vh]">
                <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
        </DashboardLayout>
    );

    return (
        <DashboardLayout>
            <div className="mb-10">
                <h2 className="text-3xl font-black text-slate-900 tracking-tight">Identity Management</h2>
                <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-2">Manage your personal security and profile settings</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                {/* Profile Card */}
                <div className="lg:col-span-1">
                    <div className="bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden shadow-sm p-8 text-center">
                        <div className="relative w-32 h-32 mx-auto mb-6">
                            <div className="w-full h-full bg-indigo-600 rounded-[2rem] flex items-center justify-center text-white font-black text-4xl shadow-2xl shadow-indigo-100">
                                {profile.name[0]?.toUpperCase()}
                            </div>
                            <button className="absolute bottom-0 right-0 w-10 h-10 bg-white border border-slate-200 rounded-xl flex items-center justify-center text-slate-500 hover:text-indigo-600 shadow-lg group">
                                <Camera size={18} className="group-hover:scale-110 transition-transform" />
                            </button>
                        </div>

                        <h3 className="text-xl font-black text-slate-900 leading-tight">{profile.name}</h3>
                        <p className="text-xs text-indigo-600 font-bold uppercase tracking-widest mt-2">{(session?.user as any)?.role} Level</p>

                        <div className="mt-8 pt-8 border-t border-slate-50 space-y-4">
                            <div className="flex items-center justify-between text-left px-4 py-3 bg-slate-50 rounded-2xl">
                                <div>
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">Account Status</p>
                                    <p className="text-xs font-bold text-slate-800 mt-1">Verified & Secure</p>
                                </div>
                                <CheckCircle2 size={16} className="text-emerald-500" />
                            </div>
                            <div className="flex items-center justify-between text-left px-4 py-3 bg-slate-50 rounded-2xl">
                                <div>
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">Security Encryption</p>
                                    <p className="text-xs font-bold text-slate-800 mt-1">AES-256 Multi-layer</p>
                                </div>
                                <Shield size={16} className="text-indigo-500" />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Edit Form */}
                <div className="lg:col-span-2">
                    <form onSubmit={handleSubmit} className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden p-10">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Full Legal Name</label>
                                <div className="relative">
                                    <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                                    <input
                                        type="text"
                                        value={profile.name}
                                        onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold text-slate-800 focus:bg-white focus:border-indigo-600 transition-all outline-none"
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Primary Email Address</label>
                                <div className="relative">
                                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                                    <input
                                        type="email"
                                        value={profile.email}
                                        onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold text-slate-800 focus:bg-white focus:border-indigo-600 transition-all outline-none"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="h-[1px] bg-slate-100 my-10"></div>

                        <div className="mb-6">
                            <h4 className="font-black text-slate-900 flex items-center gap-2">
                                <Lock size={18} className="text-indigo-600" />
                                Security Credentials Update
                            </h4>
                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Leave blank to maintain current password</p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Current Password Verification</label>
                                <input
                                    type="password"
                                    autoComplete="off"
                                    value={profile.currentPassword}
                                    onChange={(e) => setProfile({ ...profile, currentPassword: e.target.value })}
                                    placeholder="••••••••"
                                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-6 text-sm font-bold text-slate-800 focus:bg-white focus:border-indigo-600 transition-all outline-none"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">New Secure Password</label>
                                <input
                                    type="password"
                                    autoComplete="new-password"
                                    value={profile.newPassword}
                                    onChange={(e) => setProfile({ ...profile, newPassword: e.target.value })}
                                    placeholder="Minimum 8 characters"
                                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-6 text-sm font-bold text-slate-800 focus:bg-white focus:border-indigo-600 transition-all outline-none"
                                />
                            </div>
                        </div>

                        <div className="mt-12 flex items-center gap-4 p-6 bg-indigo-50/50 rounded-3xl border border-indigo-100/50">
                            <AlertCircle className="text-indigo-600" size={24} />
                            <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
                                Updating your profile will log an entry in the system audit logs. All security modifications are monitored by the JTECH Enterprise Compliance team.
                            </p>
                            <button
                                type="submit"
                                disabled={saving}
                                className="ml-auto bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black flex items-center gap-2 hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all active:scale-95 disabled:opacity-70"
                            >
                                {saving ? "Optimizing..." : (
                                    <>
                                        <Save size={20} />
                                        Synchronize Changes
                                    </>
                                )}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </DashboardLayout>
    );
}
