"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Lock, Mail, ArrowRight, Loader2 } from "lucide-react";
import toast from "react-hot-toast";

export default function LoginPage() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const router = useRouter();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            const res = await signIn("credentials", {
                email,
                password,
                redirect: false,
            });

            if (res?.error) {
                toast.error(res.error);
            } else {
                toast.success("Welcome back to JTECH!");
                router.push("/dashboard");
            }
        } catch (error) {
            toast.error("An unexpected error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
            <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-100">
                {/* Left Side: Form */}
                <div className="p-12 lg:p-16 flex flex-col justify-center">
                    <div className="mb-10">
                        <div className="relative w-12 h-12 mb-6">
                            <Image
                                src="/logo.png"
                                alt="JTECH Logo"
                                fill
                                className="object-contain"
                            />
                        </div>
                        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">System Login</h1>
                        <p className="text-slate-500 mt-2 font-medium">Access your JTECH Employee Management Portal</p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-sm font-bold text-slate-700 ml-1">Email Address</label>
                            <div className="relative group">
                                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={18} />
                                <input
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    placeholder="name@jtech.com"
                                    required
                                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-12 pr-4 outline-none focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all font-medium text-slate-800"
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-sm font-bold text-slate-700 ml-1">Password</label>
                            <div className="relative group">
                                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={18} />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="••••••••"
                                    required
                                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-12 pr-4 outline-none focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all font-medium text-slate-800"
                                />
                            </div>
                        </div>

                        <div className="flex items-center justify-between py-2">
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500" />
                                <span className="text-sm text-slate-600 font-medium">Remember me</span>
                            </label>
                            <a href="#" className="text-sm font-bold text-indigo-600 hover:text-indigo-700">Forgot password?</a>
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full bg-indigo-600 text-white rounded-xl py-4 font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 shadow-lg shadow-indigo-200 active:scale-[0.98] transition-all disabled:opacity-70"
                        >
                            {isLoading ? (
                                <Loader2 className="animate-spin" size={20} />
                            ) : (
                                <>
                                    Enter Dashboard
                                    <ArrowRight size={20} />
                                </>
                            )}
                        </button>
                    </form>

                    <div className="mt-12 pt-8 border-t border-slate-100">
                        <p className="text-xs text-slate-400 font-medium text-center uppercase tracking-widest leading-relaxed">
                            JTECH Internal Corporate System &copy; {new Date().getFullYear()} <br />
                            Secure Enterprise Environment
                        </p>
                    </div>
                </div>

                {/* Right Side: Visual */}
                <div className="hidden lg:block relative bg-slate-900 overflow-hidden">
                    <Image
                        src="/login-bg.png"
                        alt="JTECH EMS"
                        fill
                        className="object-cover opacity-80"
                    />
                    <div className="absolute inset-0 bg-gradient-to-tr from-indigo-900/40 to-transparent"></div>
                    <div className="absolute bottom-12 left-12 right-12 p-8 glass-card rounded-3xl border-slate-700/30">
                        <div className="flex items-center gap-2 text-indigo-400 mb-2">
                            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Platform Advantage</span>
                        </div>
                        <h3 className="text-white text-xl font-bold mb-2">Modern Workforce Management</h3>
                        <p className="text-slate-300 text-sm leading-relaxed">
                            Experience the next generation of employee tracking and task management. Built for performance, designed for excellence.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}
