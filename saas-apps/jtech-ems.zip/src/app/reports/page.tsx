"use client";

import { DashboardLayout } from "@/components/DashboardLayout";
import { BarChart3, FileText, Download, TrendingUp, PieChart, Activity } from "lucide-react";
import toast from "react-hot-toast";

export default function ReportsPage() {
    const reportCategories = [
        { name: "Operational Efficiency", icon: Activity, count: 12, size: "1.2MB" },
        { name: "Security Audit (Q1)", icon: FileText, count: 4, size: "850KB" },
        { name: "Personnel Allocation", icon: TrendingUp, count: 8, size: "2.1MB" },
        { name: "Resource Monitoring", icon: PieChart, count: 15, size: "4.5MB" },
    ];

    return (
        <DashboardLayout>
            <div className="flex items-center justify-between mb-10">
                <div>
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">Enterprise Analytics</h2>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-2 flex items-center gap-2">
                        <BarChart3 size={12} className="text-indigo-600" />
                        BI intelligence & Reporting Hub
                    </p>
                </div>
                <button
                    onClick={() => toast.success("Building comprehensive system snapshot...")}
                    className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-black flex items-center gap-3 hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all active:scale-95"
                >
                    <Download size={20} />
                    Generate Master Report
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
                {reportCategories.map((cat, i) => (
                    <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm hover:shadow-xl transition-all group cursor-pointer">
                        <div className="flex items-center justify-between mb-6">
                            <div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                                <cat.icon size={26} />
                            </div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{cat.size}</span>
                        </div>
                        <h3 className="text-xl font-black text-slate-900 mb-2">{cat.name}</h3>
                        <p className="text-sm text-slate-500 font-medium">Contains {cat.count} detailed sub-reports and metadata graphs.</p>
                        <div className="mt-8 flex items-center justify-between">
                            <button className="text-indigo-600 text-[10px] font-black uppercase tracking-widest hover:underline">View Archive</button>
                            <button className="text-slate-400 hover:text-slate-900 transition-colors">
                                <Download size={18} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            <div className="bg-slate-900 p-10 rounded-[3rem] shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="max-w-md">
                        <h4 className="text-2xl font-black text-white mb-4">Advanced Query Engine</h4>
                        <p className="text-slate-400 text-sm leading-relaxed mb-6 font-medium">
                            Execute direct analytics queries against the enterprise data core. Use standard J-Query syntax for filtering.
                        </p>
                        {/* VULNERABILITY: SQL INJECTION VECTOR? */}
                        <div className="flex gap-4">
                            <input
                                type="text"
                                placeholder="Enter analytics query..."
                                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-5 py-3 text-white text-sm outline-none focus:border-indigo-500 transition-all font-mono"
                            />
                            <button
                                onClick={() => toast.error("Diagnostic Access Required: Please use the /api/debug endpoint for raw telemetry.")}
                                className="bg-white text-slate-900 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-100"
                            >
                                Run
                            </button>
                        </div>
                    </div>
                    <div className="w-full max-w-[300px] aspect-square bg-white/5 rounded-[2rem] border border-white/10 flex flex-col items-center justify-center p-8 text-center">
                        <Activity size={48} className="text-indigo-400 mb-4 animate-pulse" />
                        <p className="text-white font-black text-sm uppercase tracking-widest">Live Engine</p>
                        <p className="text-slate-500 text-[10px] mt-2 font-bold leading-tight">Secure connection to J-Analytics core verified.</p>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}
