"use client";

import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import {
    CheckSquare,
    Clock,
    AlertCircle,
    Plus,
    User,
    ExternalLink,
    CalendarDays,
    Search,
    Trash2
} from "lucide-react";
import axios from "axios";
import { format } from "date-fns";
import toast from "react-hot-toast";
import { TaskModal } from "@/components/TaskModal";

export default function TasksPage() {
    const [tasks, setTasks] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [search, setSearch] = useState("");

    const fetchTasks = async (query = "") => {
        setLoading(true);
        try {
            const res = await axios.get(`/api/tasks?search=${encodeURIComponent(query)}`);
            setTasks(res.data);
        } catch (err) {
            toast.error("Failed to load tasks");
        } finally {
            setLoading(false);
        }
    };

    const updateStatus = async (id: string, newStatus: string) => {
        try {
            await axios.patch("/api/tasks", { id, status: newStatus });
            toast.success("Task updated");
            fetchTasks(search);
        } catch (err) {
            toast.error("Failed to update task");
        }
    };

    const deleteTask = async (id: string) => {
        if (!confirm("Are you sure you want to terminate this operational record?")) return;
        try {
            await axios.delete(`/api/tasks?id=${id}`);
            toast.success("Mission Deleted");
            fetchTasks(search);
        } catch (err) {
            toast.error("Deletion failed");
        }
    };

    useEffect(() => {
        fetchTasks(search);
    }, []);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        fetchTasks(search);
    };

    return (
        <DashboardLayout>
            <TaskModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSuccess={() => fetchTasks(search)}
            />
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">Task Intelligence</h2>
                    <p className="text-slate-400 font-medium">Track assignments and milestone progress</p>
                </div>

                <div className="flex flex-1 max-w-xl gap-3">
                    <form onSubmit={handleSearch} className="relative flex-1">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <input
                            type="text"
                            placeholder="Identify mission or operative..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-2xl py-3 pl-12 pr-4 outline-none focus:ring-4 focus:ring-indigo-50 focus:border-indigo-600 transition-all font-bold text-slate-700 shadow-sm"
                        />
                    </form>
                    <button
                        onClick={() => setIsModalOpen(true)}
                        className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all active:scale-95"
                    >
                        <Plus size={20} />
                        Delegate
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Kanban-like simple columns */}
                {["PENDING", "IN_PROGRESS", "COMPLETED"].map((status) => (
                    <div key={status} className="flex flex-col gap-4">
                        <div className="flex items-center justify-between px-2">
                            <div className="flex items-center gap-2">
                                <div className={`w-2 h-2 rounded-full ${status === "PENDING" ? "bg-amber-500" :
                                    status === "IN_PROGRESS" ? "bg-blue-500" :
                                        "bg-emerald-500"
                                    }`}></div>
                                <h3 className="font-black text-slate-400 text-xs uppercase tracking-[0.2em]">
                                    {status.replace("_", " ")}
                                </h3>
                            </div>
                            <span className="bg-slate-100 text-slate-500 px-2 py-0.5 rounded text-[10px] font-bold">
                                {tasks.filter(t => t.status === status).length}
                            </span>
                        </div>

                        <div className="space-y-4">
                            {tasks.filter(t => t.status === status).map((task) => (
                                <div key={task.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all group">
                                    <div className="flex items-start justify-between mb-3">
                                        <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded border ${task.priority === "HIGH" ? "border-rose-100 text-rose-500" :
                                            task.priority === "MEDIUM" ? "border-amber-100 text-amber-500" :
                                                "border-blue-100 text-blue-500"
                                            }`}>
                                            {task.priority} Priority
                                        </span>
                                        <div className="flex gap-2">
                                            <button
                                                onClick={() => deleteTask(task.id)}
                                                className="text-slate-300 hover:text-rose-500 transition-colors"
                                            >
                                                <Trash2 size={14} />
                                            </button>
                                            <button className="text-slate-300 hover:text-indigo-600 transition-colors">
                                                <ExternalLink size={14} />
                                            </button>
                                        </div>
                                    </div>
                                    <h4 className="font-bold text-slate-800 leading-snug mb-2 group-hover:text-indigo-600 transition-colors">
                                        {task.title}
                                    </h4>
                                    <p className="text-sm text-slate-500 line-clamp-2 mb-4 leading-relaxed">
                                        {task.description}
                                    </p>

                                    <div className="flex items-center gap-4 pt-4 border-t border-slate-50 mt-auto">
                                        <div className="flex items-center gap-1.5 text-slate-400">
                                            <Clock size={12} />
                                            <span className="text-[10px] font-bold uppercase">{format(new Date(task.createdAt), "MMM d")}</span>
                                        </div>
                                        <div className="flex items-center gap-1.5 text-slate-400 ml-auto">
                                            <User size={12} />
                                            <span className="text-[10px] font-bold uppercase truncate max-w-[80px]">{task.assignedTo?.name || "Unassigned"}</span>
                                        </div>
                                    </div>

                                    {status !== "COMPLETED" && (
                                        <button
                                            onClick={() => updateStatus(task.id, status === "PENDING" ? "IN_PROGRESS" : "COMPLETED")}
                                            className="w-full mt-4 bg-slate-50 hover:bg-indigo-50 hover:text-indigo-600 text-slate-400 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all transition-colors"
                                        >
                                            Move to {status === "PENDING" ? "In Progress" : "Completed"}
                                        </button>
                                    )}
                                </div>
                            ))}

                            {loading && [...Array(2)].map((_, i) => (
                                <div key={i} className="bg-white/50 border border-dashed border-slate-200 h-32 rounded-2xl animate-pulse"></div>
                            ))}

                            {!loading && tasks.filter(t => t.status === status).length === 0 && (
                                <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-slate-100 rounded-3xl opacity-40">
                                    <div className="w-8 h-8 bg-slate-50 rounded-lg flex items-center justify-center mb-2">
                                        <CheckSquare size={16} className="text-slate-300" />
                                    </div>
                                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">No Tasks</p>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </DashboardLayout>
    );
}
