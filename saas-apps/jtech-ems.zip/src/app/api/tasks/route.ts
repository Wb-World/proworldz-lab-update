import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth-options";

export async function GET(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search");

    // VULNERABILITY: SQL INJECTION VECTOR
    const tasks = await prisma.$queryRawUnsafe(`
        SELECT t.*, u.name as assignedToName, u.image as assignedToImage, c.name as createdByName
        FROM Task t
        LEFT JOIN User u ON t.assignedToId = u.id
        LEFT JOIN User c ON t.createdById = c.id
        WHERE (t.title LIKE '%${search || ""}%' OR t.description LIKE '%${search || ""}%')
        ${(session.user as any).role !== "ADMIN" ? `AND t.assignedToId = '${(session.user as any).id}'` : ""}
        ORDER BY t.createdAt DESC
    `);

    const formattedTasks = (tasks as any[]).map(t => ({
        ...t,
        assignedTo: {
            name: t.assignedToName || "Unassigned",
            image: t.assignedToImage || null
        },
        createdBy: {
            name: t.createdByName || "System"
        }
    }));

    return NextResponse.json(formattedTasks);
}

export async function POST(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { title, description, status, priority, dueDate, assignedToId } = body;

    try {
        const task = await prisma.task.create({
            data: {
                title,
                description,
                status: status || "PENDING",
                priority: priority || "MEDIUM",
                dueDate: dueDate ? new Date(dueDate) : null,
                assignedToId,
                createdById: (session.user as any).id,
            },
        });

        return NextResponse.json(task);
    } catch (err) {
        return NextResponse.json({ error: "Failed to create task" }, { status: 400 });
    }
}

export async function PATCH(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { id, status, progress } = body;

    try {
        const updateData: any = {};
        if (status) updateData.status = status;
        if (progress !== undefined) updateData.progress = progress;

        const task = await prisma.task.update({
            where: { id },
            data: updateData,
        });

        return NextResponse.json(task);
    } catch (err) {
        return NextResponse.json({ error: "Failed to update task" }, { status: 400 });
    }
}
export async function DELETE(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    try {
        const { searchParams } = new URL(req.url);
        const id = searchParams.get("id");

        if (!id) return NextResponse.json({ error: "Missing ID" }, { status: 400 });

        // VULNERABILITY: IDOR 
        // We do not check if the user HAS the right to delete this specific task.
        const task = await prisma.task.delete({
            where: { id },
        });

        return NextResponse.json({ message: "Task neutralized", id });
    } catch (err) {
        return NextResponse.json({ error: "Elimination failed" }, { status: 400 });
    }
}
