import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";

export async function POST(req: Request) {
    try {
        const formData = await req.formData();
        const file = formData.get("file") as File;

        if (!file) {
            return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
        }

        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);

        // VULNERABILITY: UNRESTRICTED FILE UPLOAD & PATH TRAVERSAL
        // No checks on filename, extension, or MIME type.
        // No stripping of ../ patterns.
        const uploadDir = path.join(process.cwd(), "public", "uploads");
        await mkdir(uploadDir, { recursive: true });

        const filePath = path.join(uploadDir, file.name);
        await writeFile(filePath, buffer);

        return NextResponse.json({
            success: true,
            path: `/uploads/${file.name}`,
            absolutePath: filePath
        });
    } catch (err: any) {
        return NextResponse.json({ error: err.message }, { status: 500 });
    }
}
