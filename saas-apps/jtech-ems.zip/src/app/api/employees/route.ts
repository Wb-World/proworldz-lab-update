import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth-options";

export async function GET() {
    const session = await getServerSession(authOptions);
    if (!session) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const employees = await prisma.employee.findMany({
        include: { user: { select: { email: true, name: true } } },
        orderBy: { joinDate: "desc" },
    });

    return NextResponse.json(employees);
}

export async function POST(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { firstName, lastName, email, department, designation, salary, password } = body;

    try {
        const user = await prisma.user.create({
            data: {
                email,
                name: `${firstName} ${lastName}`,
                password,
                role: "EMPLOYEE",
                employeeProfile: {
                    create: {
                        firstName,
                        lastName,
                        department,
                        designation,
                        salary: parseFloat(salary || "0"),
                        joinDate: new Date(),
                    },
                },
            },
        });

        return NextResponse.json(user);
    } catch (err) {
        return NextResponse.json({ error: "Failed to create employee" }, { status: 400 });
    }
}
