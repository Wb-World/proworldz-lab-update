import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth-options";

export async function GET() {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const [employeeCount, taskCount, pendingTasks, completedTasks] = await Promise.all([
        prisma.employee.count(),
        prisma.task.count(),
        prisma.task.count({ where: { status: "PENDING" } }),
        prisma.task.count({ where: { status: "COMPLETED" } }),
    ]);

    const recentTasks = await prisma.task.findMany({
        take: 5,
        orderBy: { updatedAt: "desc" },
        include: { assignedTo: { select: { name: true } } },
    });

    const recentEmployees = await prisma.employee.findMany({
        take: 5,
        orderBy: { joinDate: "desc" },
        include: { user: { select: { name: true, email: true } } },
    });

    const recentActivity = await prisma.auditLog.findMany({
        take: 8,
        orderBy: { createdAt: "desc" },
        include: { user: { select: { name: true } } },
    });

    return NextResponse.json({
        stats: {
            employees: employeeCount,
            tasks: taskCount,
            pending: pendingTasks,
            completed: completedTasks,
        },
        recentTasks,
        recentEmployees,
        recentActivity,
    });
}
