import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth-options";

export async function GET() {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const notifications = await prisma.notification.findMany({
        where: { userId: (session.user as any).id },
        orderBy: { createdAt: "desc" },
        take: 10,
    });

    return NextResponse.json(notifications);
}

export async function PATCH(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { id, isRead } = body;

    try {
        const notification = await prisma.notification.update({
            where: { id },
            data: { isRead },
        });
        return NextResponse.json(notification);
    } catch (err) {
        return NextResponse.json({ error: "Failed to update notification" }, { status: 400 });
    }
}

export async function DELETE(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
        await prisma.notification.delete({ where: { id } });
    } else {
        await prisma.notification.deleteMany({
            where: { userId: (session.user as any).id, isRead: true }
        });
    }

    return NextResponse.json({ success: true });
}
