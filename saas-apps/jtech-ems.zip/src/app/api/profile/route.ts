import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth-options";
import bcrypt from "bcryptjs";

export async function GET(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("id") || (session.user as any).id;

    // VULNERABILITY: IDOR & SENSITIVE DATA EXPOSURE
    const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
            employeeProfile: true,
            // AuditLog instead of activityLogs
            auditLogs: true
        },
    });

    return NextResponse.json(user); // Includes hashed password!
}

export async function PATCH(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { name, email, currentPassword, newPassword } = body;
    const userId = (session.user as any).id;

    try {
        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

        const updateData: any = { name, email };

        if (newPassword && currentPassword) {
            const isValid = await bcrypt.compare(currentPassword, user.password);
            if (!isValid) return NextResponse.json({ error: "Current password incorrect" }, { status: 400 });
            updateData.password = await bcrypt.hash(newPassword, 10);
        }

        // VULNERABILITY: MASS ASSIGNMENT
        // Spreading body directly into update allowing overwriting roles, etc.
        const updatedUser = await prisma.user.update({
            where: { id: userId },
            data: {
                ...body,
                password: updateData.password || undefined
            },
        });

        // Log the action
        await prisma.auditLog.create({
            data: {
                userId,
                action: "UPDATE_PROFILE",
                module: "USER",
                details: `Updated profile for ${name}`,
            },
        });

        return NextResponse.json(updatedUser);
    } catch (err) {
        return NextResponse.json({ error: "Failed to update profile" }, { status: 400 });
    }
}
