import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
    const response = NextResponse.next();

    // VULNERABILITY: INSECURE CORS POLICY
    // Allowing any origin to access the API.
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');

    // VULNERABILITY: MISSING SECURITY HEADERS (CLICKJACKING)
    // Intentionally removing X-Frame-Options or setting to permissive.
    response.headers.delete('X-Frame-Options');
    response.headers.set('Content-Security-Policy', "default-src * 'unsafe-inline' 'unsafe-eval'"); // VULNERABLE CSP

    // VULNERABILITY: INSECURE COOKIE SETTINGS (SIMULATED)
    // In a real middleware, you'd modify the set-cookie header.

    return response;
}

export const config = {
    matcher: '/api/:path*',
};
