const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    console.log('🔄 Re-initializing Enterprise Database (MySQL)...');

    // Clear existing data (Order matters for foreign keys)
    await prisma.auditLog.deleteMany({});
    await prisma.notification.deleteMany({});
    await prisma.attachment.deleteMany({});
    await prisma.task.deleteMany({});
    await prisma.employee.deleteMany({});
    await prisma.user.deleteMany({});

    const adminPassword = await bcrypt.hash('admin123', 10);
    const employeePassword = await bcrypt.hash('user123', 10);

    // 1. Create Core Administrators
    const admin = await prisma.user.create({
        data: {
            email: 'admin@jtech.com',
            password: adminPassword,
            name: 'Richard Chen (System Admin)',
            role: 'ADMIN',
        },
    });

    // 2. Log Admin initialization
    await prisma.auditLog.create({
        data: {
            userId: admin.id,
            action: 'SYSTEM_BOOT',
            module: 'CORE',
            details: 'Enterprise Management System core modules initialized.',
        }
    });

    // 3. Create Departmental Force
    const employeesData = [
        { name: 'Sarah Miller', email: 'sarah@jtech.com', dept: 'Engineering', desig: 'Lead Architect', performance: 94 },
        { name: 'Marcus Vane', email: 'marcus@jtech.com', dept: 'Cybersecurity', desig: 'SecOps Lead', performance: 88 },
        { name: 'Elena Rodriguez', email: 'elena@jtech.com', dept: 'Marketing', desig: 'Growth VP', performance: 91 },
        { name: 'Liam Foster', email: 'liam@jtech.com', dept: 'Product', desig: 'Product Owner', performance: 85 },
    ];

    for (const emp of employeesData) {
        const user = await prisma.user.create({
            data: {
                email: emp.email,
                password: employeePassword,
                name: emp.name,
                role: 'EMPLOYEE',
                employeeProfile: {
                    create: {
                        firstName: emp.name.split(' ')[0],
                        lastName: emp.name.split(' ')[1],
                        department: emp.dept,
                        designation: emp.desig,
                        salary: 75000 + Math.random() * 45000,
                        joinDate: new Date(),
                    }
                }
            },
        });

        // Create a Welcome Notification
        await prisma.notification.create({
            data: {
                userId: user.id,
                title: 'Welcome to JTECH Cloud',
                message: `System access granted. Your payroll and task modules are now active in the ${emp.dept} division.`,
                type: 'SUCCESS',
            }
        });

        // Assign Tasks with Status and Progress
        const taskTitles = [
            `Migrate ${emp.dept} Legacy Data`,
            `Security Audit - Phase 1`,
            `Strategy Blueprint v2`,
        ];

        for (let i = 0; i < Math.floor(Math.random() * 3) + 1; i++) {
            await prisma.task.create({
                data: {
                    title: taskTitles[i],
                    description: `Critical operational task for the ${emp.dept} department involving high-level optimization.`,
                    status: i === 0 ? 'IN_PROGRESS' : 'PENDING',
                    priority: i === 0 ? 'HIGH' : 'MEDIUM',
                    progress: i === 0 ? 45 : 0,
                    assignedToId: user.id,
                    createdById: admin.id,
                    dueDate: new Date(Date.now() + (7 * 24 * 60 * 60 * 1000)), // 7 days from now
                }
            });
        }

        // Log user creation
        await prisma.auditLog.create({
            data: {
                userId: admin.id,
                action: 'ONBOARD_EMPLOYEE',
                module: 'HR',
                details: `Provisioned account for ${emp.name} in ${emp.dept}.`,
            }
        });
    }

    console.log('✅ JTECH Enterprise Data Seeded Successfully!');
}

main()
    .catch((e) => {
        console.error('❌ Seeding Error:', e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
